package com.orientechnologies.orient.core.db.record;

public interface OIdentityChangeListener {
  public void onBeforeIdentityChanged();
}
