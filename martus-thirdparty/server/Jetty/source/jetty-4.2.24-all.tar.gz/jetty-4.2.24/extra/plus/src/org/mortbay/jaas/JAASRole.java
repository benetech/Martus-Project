// ======================================================================
// Copyright (C) 2003 by Mortbay Consulting Ltd
// $Id: JAASRole.java,v 1.1 2003/04/30 14:00:49 janb Exp $ 
// ======================================================================

package org.mortbay.jaas;

import java.security.Principal;


public class JAASRole extends JAASPrincipal
{
    
    public JAASRole(String name)
    {
        super (name);
    }

    public boolean equals (Object o)
    {
        if (! (o instanceof Principal))
            return false;

        return getName().equals(((Principal)o).getName());
    }
}
