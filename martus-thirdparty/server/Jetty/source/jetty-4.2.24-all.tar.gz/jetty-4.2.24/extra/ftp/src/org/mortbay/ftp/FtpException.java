// ===========================================================================
// Copyright (c) 1996 Mort Bay Consulting Pty. Ltd. All rights reserved.
// Copyright (c) 1996 Optimus Solutions Pty. Ltd. All rights reserved.
// $Id: FtpException.java,v 1.1 2003/05/01 21:40:26 gregwilkins Exp $
// ---------------------------------------------------------------------------

package org.mortbay.ftp;

public class FtpException extends java.io.IOException
{
    /* ------------------------------------------------------------------ */
    FtpException(String msg)
    {
        super(msg);
    }
}
