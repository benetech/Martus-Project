
This directory contains the servlets for the Jetty demo.

This directory is configured to be used by the /demo context by
the $JETTY_HOME/etc/demo.xml file.

It is not a default directory for user servlets.  Please read the
jetty tutorial for details.


