
This directory contains the source, content and webapplications for the
Jetty demo.  It is configured in the $JETTY_HOME/etc/demo.xml file.

It can be run with:

  cd $JETTY_HOME
  bin/jetty.sh run etc/demo.xml

Or if your classpath is setup:

  java org.mortbay.jetty.Server etc/demo.xml





