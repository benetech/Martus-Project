Modified LZMA library for NSIS
------------------------------

    Copyright (c) 1999-2003 Igor Pavlov

    All files in this folder and it's subfolders are 
    licensed under GNU LGPL.
    Most of these files were copied from source code 
    of 7-Zip compression program:

    http://www.7-zip.org

    Some of the files were modified and are not an
    exact replica of the original files.
    
    LZMA is default and general compression method of 7z format in 7-Zip. 
    The main features of LZMA method:
       - High compression ratio
       - High decompressing speed: about 10-20 MB/s on 2 GHz CPU
       - Small memory requirements for decompressing
       - Small code size for decompressing: about 5 KB


    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.
