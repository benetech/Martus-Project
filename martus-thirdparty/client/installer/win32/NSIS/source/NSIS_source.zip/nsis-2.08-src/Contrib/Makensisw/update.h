/* Initialize update objects. */
void InitializeUpdate();

/* Check for newer version on server and show a message to the user. */
void Update();

/* Finalize update objects. */
void FinalizeUpdate();
