// StdAfx.h

#ifndef __STDAFX_H
#define __STDAFX_H

#include "../../Platform.h"

#endif 
