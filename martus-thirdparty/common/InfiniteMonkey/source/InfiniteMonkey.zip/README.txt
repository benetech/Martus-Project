Infinite Monkey version 1.0
===========================
This is ISNetworks' implentation of a Java SecureRandom provider. It uses /dev/urandom on UNIX systems, and the Microsoft CryptoAPI via JNI on Windows.

The default implementation of SecureRandom on most JDKs spins up an enormous number of threads and uses that to seed the random number generator. This takes quite some time, 5-30 seconds depending on the system. In order to improve the apparent performance of cryptographic operations, we wrote this implementation to skip the lengthy non-native seeding process. Instead, we go directly to the underlying operating system and let it provide randomness. 

On Windows this is done through a call to the CryptoAPI using JNI. On UNIX, all randomness is fetched from /dev/urandom. JDK 1.4 also provides a SecureRandom implementation that can use /dev/urandom on UNIX systems, so if you're using that version on a supported OS (e.g. Linux), you likely do not need Infinite Monkey.

This software is provided under an Apache-style license, meaning you are free to use it for commercial or non-commercial use. Read the license file for more information.

Check http://www.isnetworks.com/infinitemonkey for new releases of this software.


INSTALLING
==========
To install, add the jar file, InfiniteMonkey.jar, to your lib/ext director(y|ies). Under UNIX, it will be in 

$JAVA_HOME/jre/lib/ext

Under Windows, it will be in 

%JAVA_HOME%\jre\lib\ext

as well as under a similar location in your JRE: most likely 

C:\Program Files\JavaSoft\JRE\1.3\lib\ext

You can also add the jar to your classpath if you prefer.

IF you're using Windows, you also need to have the directory containing infinitemonkey.dll in your PATH.


CONFIGURATION
=============
In order to use Infinite Monkey, you must register it as a security provider. There are two ways to do this: dynamically or statically. To dynamically add register a provider, put the following statement in your code:

java.security.Security.insertProviderAt(new com.isnetworks.provider.random.InfiniteMonkeyProvider(),1);

To register the provider statically, you need to create an entry for it in your java.security file. This will be in a location near your lib/ext director(y|ies). Rather than lib/ext, look in lib/security. You will see some lines like the following: 

security.provider.1=sun.security.provider.Sun
security.provider.2=com.sun.rsajca.Provider

Add the ISNetworks provider by inserting the following line at the top of the list: 

security.provider.1=com.isnetworks.provider.random.InfiniteMonkeyProvider

And move the other providers down a notch:

security.provider.2=sun.security.provider.Sun
security.provider.3=com.sun.rsajca.Provider


USING
=====
By constructing a new SecureRandom instance with new SecureRandom(), you will automatically be using the InfiniteMonkey provider.

If you're on a system that provides a file like /dev/urandom but with a different name, you can specify it by setting the system property "java.security.egd" to that filename, like so:

java -Djava.security.egd=/dev/random ClassToExecute

Alternatively you can set it programmatically with System.setProperty("java.security.egd","/dev/random").


CONTACT
=======
If you have any comments you'd like to make, or improvements you'd like to contribute to this codebase, feel free to contact Jess Garms (jess_garms@isnetworks.com). 


HISTORY
=======
v1.0 Initial release


AUTHORS
=======
Joe Mobley
Josh Eckels
Jess Garms


SHAMELESS PLUG
==============
If you wish to know more about using cryptography in Java, check out Professional Java Security by Jess Garms and Daniel Somerfield, published by Wrox Press. 

