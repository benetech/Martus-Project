
#ifndef InfiniteMonkey_h
#define InfiniteMonkey_h

#include "NativeObject.h"

class InfiniteMonkey : public NativeObject {
	typedef NativeObject super;

public:

	static InfiniteMonkey*   getInstance               (jobject javaObject);
	static void              releaseInstance           (InfiniteMonkey* instance);

	void                     nextBytes                 (jbyteArray bytes);
	jbyteArray               generateSeed              (jint numBytes);
	void                     setSeed                   (jbyteArray seed);
	jstring	                 getUnderlyingProviderName ();

protected:

	                         InfiniteMonkey            (jobject javaObject);
	                        ~InfiniteMonkey            ();

private:

	static void              lockClass                 ();
	static void              unlockClass               ();

	static int               mClassLock;
	static jclass            mJavaClass;
	static jmethodID         mDefaultConstructorMethodId;
	static jfieldID          mNativeObjectFieldId;
	static jfieldID          mUsingHardwareOnlyFieldId;

	HCRYPTPROV               mProviderHandle;

};

#endif // InfiniteMonkey_h
