
#include "InfiniteMonkey.h"
#include "com_isnetworks_provider_random_Win32InfiniteMonkey.h"

// --------------------------------------------------------------------------
// static member initialization.
// --------------------------------------------------------------------------

int      InfiniteMonkey::mClassLock = 0;
jclass   InfiniteMonkey::mJavaClass;
jfieldID InfiniteMonkey::mNativeObjectFieldId;
jfieldID InfiniteMonkey::mUsingHardwareOnlyFieldId;

// --------------------------------------------------------------------------
// class stuff.
// --------------------------------------------------------------------------

void InfiniteMonkey::lockClass() {
	if (mClassLock++ == 0) {
		mJavaClass                     = findAndLockClass("com/isnetworks/provider/random/Win32InfiniteMonkey");
		mNativeObjectFieldId           = getFieldId(mJavaClass, "mNativeObject", "I");
		mUsingHardwareOnlyFieldId      = getFieldId(mJavaClass, "mUsingHardwareOnly", "Z");
	}
}

void InfiniteMonkey::unlockClass() {
	if (--mClassLock == 0) {
		unlockObject(mJavaClass);
	}
}

// --------------------------------------------------------------------------
// instance management.
// --------------------------------------------------------------------------

InfiniteMonkey* InfiniteMonkey::getInstance(jobject javaObject) {

	lockClass();

	InfiniteMonkey* instance = (InfiniteMonkey*)getIntField(javaObject, mNativeObjectFieldId);
	if (instance == NULL) {
		instance = new InfiniteMonkey(javaObject);
	}
	else {
		unlockClass();
	}

	return instance;
}

void InfiniteMonkey::releaseInstance(InfiniteMonkey* instance) {
	delete instance;
	unlockClass();
}

// --------------------------------------------------------------------------
// protected constructors and destructor.
// --------------------------------------------------------------------------

InfiniteMonkey::InfiniteMonkey(jobject javaObject)
: super(javaObject, mNativeObjectFieldId)
{
	// acquire the default cryptographic service provider.
	CRYPTOCALL(::CryptAcquireContext(
		&mProviderHandle,      // HCRYPTPROV *phProv
		NULL,                  // LPCTSTR pszContainer
		NULL,                  // LPCTSTR pszProvider
		kProviderType,         // DWORD dwProvType
		CRYPT_VERIFYCONTEXT)); // DWORD dwFlags

#if 1
	// obsequiously suggest that the provider should only use hardware random number generation.
	BOOL gotHardware = ::CryptSetProvParam(
		mProviderHandle,     // HCRYPTPROV hProv
		PP_USE_HARDWARE_RNG, // DWORD dwParam
		NULL,                // BYTE *pbData
		0);                  // DWORD dwFlags
#else
	// humbly inquire as to the availability of a hardware random number generator.
	BOOL gotHardware = ::CryptGetProvParam(mProviderHandle, PP_USE_HARDWARE_RNG, NULL, NULL, 0);
#endif

	// store hardware status in java object.
	setBooleanField(mUsingHardwareOnlyFieldId, (jboolean)gotHardware);

}

InfiniteMonkey::~InfiniteMonkey() {
	CRYPTOCALL(::CryptReleaseContext(mProviderHandle, 0));
}

// --------------------------------------------------------------------------
// instance methods.
// --------------------------------------------------------------------------

void InfiniteMonkey::nextBytes(jbyteArray bytes) {

	jsize byteCount = getArrayLength(bytes);
	jbyte* byteElements = getArrayElements(bytes);

	CRYPTOCALL(::CryptGenRandom(
		mProviderHandle,        // HCRYPTPROV hProv,
		byteCount,              // DWORD dwLen,
		(BYTE*)byteElements));  // BYTE *pbBuffer

	releaseArrayElements(bytes, byteElements, 0);

}

jbyteArray InfiniteMonkey::generateSeed(jint numBytes) {

	jbyteArray array = newByteArray(numBytes);
	nextBytes(array);
	return array;
}

void InfiniteMonkey::setSeed(jbyteArray seed) {

	jsize byteCount = getArrayLength(seed);
	jbyte* seedElements = getArrayElements(seed);

	CRYPTOCALL(::CryptGenRandom(
		mProviderHandle,        // HCRYPTPROV hProv,
		byteCount,              // DWORD dwLen,
		(BYTE*)seedElements));  // BYTE *pbBuffer

	releaseArrayElements(seed, seedElements, JNI_ABORT);

}

jstring InfiniteMonkey::getUnderlyingProviderName() {

	DWORD length;
	CRYPTOCALL(::CryptGetProvParam(mProviderHandle, PP_NAME, NULL, &length, 0));
	char* utfName = new char[length];
	CRYPTOCALL(::CryptGetProvParam(mProviderHandle, PP_NAME, (BYTE*)utfName, &length, 0));
	jstring name = newStringUTF(utfName);
	delete[] utfName;
	return name;
}

// --------------------------------------------------------------------------
// Native Methods.
// --------------------------------------------------------------------------

/*
 * Class:     com_isnetworks_security_InfiniteMonkey
 * Method:    finalize
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_com_isnetworks_provider_random_Win32InfiniteMonkey_finalize
  (JNIEnv *jni, jobject javaObject)
{
	try {
		InfiniteMonkey::setEnvironment(jni);
		InfiniteMonkey* instance = InfiniteMonkey::getInstance(javaObject);
		InfiniteMonkey::releaseInstance(instance);
	}
	catch (...) {
		NativeObject::finalException();
	}
}

/*
 * Class:     com_isnetworks_security_InfiniteMonkey
 * Method:    engineNextBytes
 * Signature: ([B)V
 */
JNIEXPORT void JNICALL Java_com_isnetworks_provider_random_Win32InfiniteMonkey_engineNextBytes
  (JNIEnv *jni, jobject javaObject, jbyteArray bytes)
{
	try {
		InfiniteMonkey::setEnvironment(jni);
		InfiniteMonkey* instance = InfiniteMonkey::getInstance(javaObject);
		instance->nextBytes(bytes);
	}
	catch (...) {
		NativeObject::finalException();
	}
}

/*
 * Class:     com_isnetworks_security_InfiniteMonkey
 * Method:    engineGenerateSeed
 * Signature: (I)[B
 */
JNIEXPORT jbyteArray JNICALL Java_com_isnetworks_provider_random_Win32InfiniteMonkey_engineGenerateSeed
  (JNIEnv *jni, jobject javaObject, jint numBytes)
{
	try {
		InfiniteMonkey::setEnvironment(jni);
		InfiniteMonkey* instance = InfiniteMonkey::getInstance(javaObject);
		return instance->generateSeed(numBytes);
	}
	catch (...) {
		NativeObject::finalException();
	}
	return NULL;
}


/*
 * Class:     com_isnetworks_security_InfiniteMonkey
 * Method:    engineSetSeed
 * Signature: ([B)V
 */
JNIEXPORT void JNICALL Java_com_isnetworks_provider_random_Win32InfiniteMonkey_engineSetSeed
  (JNIEnv *jni, jobject javaObject, jbyteArray seed)
{
	try {
		InfiniteMonkey::setEnvironment(jni);
		InfiniteMonkey* instance = InfiniteMonkey::getInstance(javaObject);
		instance->setSeed(seed);
	}
	catch (...) {
		NativeObject::finalException();
	}
}

/*
 * Class:     com_isnetworks_security_InfiniteMonkey
 * Method:    getUnderlyingProviderName
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_com_isnetworks_provider_random_Win32InfiniteMonkey_getUnderlyingProviderName
  (JNIEnv *jni, jobject javaObject)
{
	try {
		InfiniteMonkey::setEnvironment(jni);
		InfiniteMonkey* instance = InfiniteMonkey::getInstance(javaObject);
		return instance->getUnderlyingProviderName();
	}
	catch (...) {
		NativeObject::finalException();
	}
	return NULL;
}


