
#ifndef NativeObject_h
#define NativeObject_h

#include <windows.h>
#include <wincrypt.h>
#include <jni.h>

const unsigned long kEncodingType = (X509_ASN_ENCODING | PKCS_7_ASN_ENCODING);
const unsigned long kProviderType = PROV_RSA_FULL;

class JavaException {};

class CryptoException {
public:
	CryptoException(unsigned long error, const char* file, int line) : message(NULL) {
		this->error   = error;
		this->file    = file;
		this->line    = line;
	}
	CryptoException(const char* message, const char* file, int line) : message(message) {
		this->error = 0;
		this->file  = file;
		this->line  = line;
	}
	const char*   message;
	unsigned long error;
	const char*   file;
	int           line;
};

#define CRYPTOCALL(result) CryptoCall(result, __FILE__, __LINE__)

static void CryptoCall(BOOL result, char* file, int line) {
	if (!result) {
		throw CryptoException(::GetLastError(), file, line);
	}
}

class NativeObject {

public:

	static void            setEnvironment        (JNIEnv* jni);
	static jclass          findClass             (const char* name);
	static jclass          findAndLockClass      (const char* name);
	static jfieldID        getFieldId            (jclass javaClass, const char* name, const char* signature);
	static jmethodID       getMethodId           (jclass javaClass, const char* name, const char* signature);
	static jint            getIntField           (jobject javaObject, jfieldID id);
	static jobject         lockObject            (jobject obj);
	static void            unlockObject          (jobject globalRef);

	jobject                getJavaObject         ();

	static void            checkException        ();
	static void            setException          (const char* name, const char* message);
	static void            throwException        (const char* name, const char* message);
	static void            finalException        ();

	static jobject         newObject             (char* className);
	static jobject         newObject             (jclass javaClass);
	static jobject         newObject             (jclass javaClass, jmethodID ctor);

	jint                   getIntField           (jfieldID id);
	void                   setIntField           (jfieldID id, jint value);
	void                   setBooleanField       (jfieldID id, jboolean value);
	void                   setObjectField        (jfieldID id, jobject value);

	void                   callVoidMethod        (jmethodID method, ...);
	jobject                callObjectMethod      (jmethodID method, ...);
	jboolean               callBooleanMethod     (jmethodID method, ...);

	static jsize           getStringLength       (jstring s);
	static const wchar_t*  getStringChars        (jstring s);
	static void            releaseStringChars    (jstring s, const wchar_t* unicode);
	static jsize           getStringUTFLength    (jstring s);
	static const char*     getStringUTFChars     (jstring s);
	static void            releaseStringUTFChars (jstring s, const char* utf);
	static jstring         newString             (const wchar_t* unicode);
	static jstring         newStringUTF          (const char* utf);

	static jsize           getArrayLength        (jarray array);
	static jbyte*          getArrayElements      (jbyteArray array);
	static void            releaseArrayElements  (jbyteArray array, jbyte* elements, jint mode);
	static jbyteArray      newByteArray          (jsize length);

protected:

	NativeObject(jobject javaObject, jfieldID nativeObjectFieldId);
	NativeObject(jclass javaClass, jmethodID ctorId, jfieldID nativeObjectFieldId);

private:

	static JNIEnv*  mJNI;

	jobject         mJavaObject;

};

#endif // NativeObject_h
