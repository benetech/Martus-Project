/*
 * InfiniteMonkey.java
 *
 * Created on August 15, 2000, 8:48 PM
 */

package com.isnetworks.provider.random;

import java.security.*;

/**
 *
 * @author  joem
 * @version
 */
public class Win32InfiniteMonkey extends SecureRandomSpi {

	public Win32InfiniteMonkey() {
	}
	
	public native void finalize();

	public native void engineNextBytes(byte[] bytes);

	public native byte[] engineGenerateSeed(int numBytes);

	public native void engineSetSeed(byte[] seed);

	public native String getUnderlyingProviderName();
	
	public boolean isUsingHardwareOnly() {
		return mUsingHardwareOnly;
	}
	
	private boolean mUsingHardwareOnly;
	private int     mNativeObject;
}
