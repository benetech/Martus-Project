/*
 * DevRandomInfiniteMonkey.java
 *
 * Created on March 3, 2002, 4:18 PM
 */

package com.isnetworks.provider.random;

import java.security.*;
import java.io.*;

/**
 *
 * @author  josh
 */
public class DevRandomInfiniteMonkey extends SecureRandomSpi {
	
	private DataInputStream mDataInputStream;
	
	static String getDevRandomFilename() {
		
		String filename = "/dev/urandom";
		
		if( System.getProperty( "java.security.egd" ) != null ) {
			filename = System.getProperty( "java.security.egd" );
		}
		
		return filename;
		
	}
	
	/** Creates a new instance of DevRandomInfiniteMonkey */
	public DevRandomInfiniteMonkey() {
		try {
			mDataInputStream = new DataInputStream( new FileInputStream( getDevRandomFilename() ) );
		}
		catch( IOException e ) {
			// This shouldn't happen, since the provider checks for the file before it
			// registers this class
			throw new IllegalStateException( getDevRandomFilename() + " exists but could not be accessed" );
		}
	}
	
	protected byte[] engineGenerateSeed(int numBytes) {
		byte[] result = new byte[ numBytes ];
		engineNextBytes( result );
		return result;
	}
	
	protected synchronized void engineNextBytes(byte[] values) {
		try {
			mDataInputStream.readFully( values );
		}
		catch( IOException e ) {
			throw new RuntimeException( "Error when attempted to read from " + getDevRandomFilename() + ": " + e );
		}
	}
	
	protected void engineSetSeed(byte[] values) {
		// We can't do anything to modify the /dev/random randomness, so we
		// silently ignore it. This allows this SecureRandom implementation
		// to be plugged into existing programs without breaking them.
	}
}
