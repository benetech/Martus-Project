/*
 * InfiniteMonkeyProvider.java
 *
 * Created on October 23, 2000, 10:49 AM
 */

package com.isnetworks.provider.random;

import java.security.*;
import java.io.*;

/**
 *
 * @author  joem
 * @version
 */
public class InfiniteMonkeyProvider extends Provider {

	private static boolean gWin32 = false;
	
	private static boolean gDevRandom = false;
	
	static {
		try {
			// Try to load the DLL. If it fails, don't register the SecureRandom
			// implementation
			System.loadLibrary("infinitemonkey");
			gWin32 = true;
		}
		catch( UnsatisfiedLinkError e ) {
			gWin32 = false;
			
			
			
			File file = new File( DevRandomInfiniteMonkey.getDevRandomFilename() );
			if( file.exists() ) {
				gDevRandom = true;
			}
		}
	}
	
	private static String getInfoString() {
		if( gWin32 ) {
			return "Infinite Monkey Provider v1.0, providing SecureRandom via the Microsoft Windows(tm) CryptoAPI";
		}
		else if( gDevRandom ) {
			return "Infinite Monkey Provider v1.0, providing SecureRandom via " + DevRandomInfiniteMonkey.getDevRandomFilename();
		}
		else {
			return "Infinite Monkey Provider v1.0, providing nothing";
		}
	}

	public InfiniteMonkeyProvider() {
		super(
			"InfiniteMonkey",
			1.0,
			getInfoString());
		if( gWin32 ) {
			put("SecureRandom.InfiniteMonkey", "com.isnetworks.provider.random.Win32InfiniteMonkey");
		}
		if( gDevRandom ) {
			put("SecureRandom.InfiniteMonkey", "com.isnetworks.provider.random.DevRandomInfiniteMonkey");
		}
	}

	public boolean isFunctioning() {
		return gWin32 || gDevRandom;
	}
	
	public boolean isDevRandomFunctioning() {
		return gDevRandom;
	}
	
	public boolean isWin32Functioning() {
		return gWin32;
	}
}
