
#include "NativeObject.h"

// --------------------------------------------------------------------------
// static variables.
// --------------------------------------------------------------------------

JNIEnv* NativeObject::mJNI = NULL;

// --------------------------------------------------------------------------
// class stuff.
// --------------------------------------------------------------------------

void NativeObject::setEnvironment(JNIEnv* jni) {
	mJNI = jni;
}

jclass NativeObject::findClass(const char* name) {
	jclass klass = mJNI->FindClass(name);
	checkException();
	return klass;
}

jclass NativeObject::findAndLockClass(const char* name) {
	jclass localRef = findClass(name);
	return (jclass)lockObject(localRef);
}

jfieldID NativeObject::getFieldId(jclass javaClass, const char* name, const char* signature) {
	jfieldID id = mJNI->GetFieldID(javaClass, name, signature);
	checkException();
	return id;
}

jmethodID NativeObject::getMethodId(jclass javaClass, const char* name, const char* signature) {
	jmethodID id = mJNI->GetMethodID(javaClass, name, signature);
	checkException();
	return id;
}

jobject NativeObject::lockObject(jobject obj) {
	jobject globalRef = mJNI->NewGlobalRef(obj);
	checkException();
	return globalRef;
}

void NativeObject::unlockObject(jobject globalRef) {
	mJNI->DeleteGlobalRef(globalRef);
	checkException();
}


jobject NativeObject::getJavaObject() {
	return mJavaObject;
}

// --------------------------------------------------------------------------
// protected constructors and destructor.
// --------------------------------------------------------------------------

NativeObject::NativeObject(jobject javaObject, jfieldID nativeObjectFieldId) {
	mJavaObject = javaObject;
	if (nativeObjectFieldId) {
		setIntField(nativeObjectFieldId, (jint)this);
	}
}

NativeObject::NativeObject(jclass javaClass, jmethodID ctorId, jfieldID nativeObjectFieldId) {
	mJavaObject = newObject(javaClass, ctorId);
	if (nativeObjectFieldId) {
		setIntField(nativeObjectFieldId, (jint)this);
	}
}

// --------------------------------------------------------------------------
// exception processing.
// --------------------------------------------------------------------------

void NativeObject::checkException() {
	if (mJNI->ExceptionOccurred()) {
		throw JavaException();
	}
}

void NativeObject::setException(const char* name, const char* message) {
	jclass klass = mJNI->FindClass(name);
	checkException();
	mJNI->ThrowNew(klass, message);
}

void NativeObject::throwException(const char* name, const char* message) {
	setException(name, message);
	throw JavaException();
}

void NativeObject::finalException() {
	if (mJNI->ExceptionOccurred() == NULL) {
		setException("java.lang.UnknownError", "critical exception in native code");
	}
}

// --------------------------------------------------------------------------
// java method access.
// --------------------------------------------------------------------------

void NativeObject::callVoidMethod(jmethodID method, ...) {
	va_list args;
	va_start(args, method);
	mJNI->CallVoidMethodV(mJavaObject, method, args);
	va_end(args);
	checkException();
}

jobject NativeObject::callObjectMethod(jmethodID method, ...) {
	va_list args;
	va_start(args, method);
	jobject returnValue = mJNI->CallObjectMethodV(mJavaObject, method, args);
	va_end(args);
	checkException();
	return returnValue;
}

jboolean NativeObject::callBooleanMethod(jmethodID method, ...) {
	va_list args;
	va_start(args, method);
	jboolean returnValue = mJNI->CallBooleanMethodV(mJavaObject, method, args);
	va_end(args);
	checkException();
	return returnValue;
}

// --------------------------------------------------------------------------
// java field access.
// --------------------------------------------------------------------------

jint NativeObject::getIntField(jobject javaObject, jfieldID id) {
	jint value = mJNI->GetIntField(javaObject, id);
	checkException();
	return value;
}

jint NativeObject::getIntField(jfieldID id) {
	return getIntField(mJavaObject, id);
}

void NativeObject::setIntField(jfieldID id, jint value) {
	mJNI->SetIntField(mJavaObject, id, value);
	checkException();
}

void NativeObject::setBooleanField(jfieldID id, jboolean value) {
	mJNI->SetBooleanField(mJavaObject, id, value);
	checkException();
}

void NativeObject::setObjectField(jfieldID id, jobject value) {
	mJNI->SetObjectField(mJavaObject, id, value);
	checkException();
}

// --------------------------------------------------------------------------
// java string manipulation.
// --------------------------------------------------------------------------

jsize NativeObject::getStringUTFLength(jstring s) {
	jsize length = mJNI->GetStringUTFLength(s);
	checkException();
	return length;
}

const char* NativeObject::getStringUTFChars(jstring s) {
	const char* utf = mJNI->GetStringUTFChars(s, NULL);
	checkException();
	return utf;
}

void NativeObject::releaseStringUTFChars(jstring string, const char* utf) {
	mJNI->ReleaseStringUTFChars(string, utf);
	checkException();
}

jstring NativeObject::newString(const wchar_t* unicode) {
	jsize length = wcslen(unicode);
	jstring s = mJNI->NewString(unicode, length);
	checkException();
	return s;
}

jstring NativeObject::newStringUTF(const char* utf) {
	jstring s = mJNI->NewStringUTF(utf);
	checkException();
	return s;
}

// --------------------------------------------------------------------------
// java array manipulation.
// --------------------------------------------------------------------------

jsize NativeObject::getArrayLength(jarray array) {
	jsize length = mJNI->GetArrayLength(array);
	checkException();
	return length;
}

jbyte* NativeObject::getArrayElements(jbyteArray array) {
	jbyte* elements = mJNI->GetByteArrayElements(array, NULL);
	checkException();
	return elements;
}

void NativeObject::releaseArrayElements(jbyteArray array, jbyte* elements, jint mode) {
	mJNI->ReleaseByteArrayElements(array, elements, mode);
	checkException();
}

jbyteArray NativeObject::newByteArray(jsize length) {
	jbyteArray array = mJNI->NewByteArray(length);
	checkException();
	return array;
}

// --------------------------------------------------------------------------
// java object creation.
// --------------------------------------------------------------------------

jobject NativeObject::newObject(char* className) {
	jclass javaClass = findClass(className);
	return newObject(javaClass);
}

jobject NativeObject::newObject(jclass javaClass) {
	jmethodID ctor = getMethodId(javaClass, "<init>", "()V");
	return newObject(javaClass, ctor);
}

jobject NativeObject::newObject(jclass javaClass, jmethodID ctor) {
	jobject instance = mJNI->NewObject(javaClass, ctor);
	checkException();
	return instance;
}


