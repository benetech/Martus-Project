// Copyright (C) 2001 Logi Ragnarsson

package org.logi.crypto.padding;

import org.logi.crypto.*;
import org.logi.crypto.sign.*;
import org.logi.crypto.keys.*;

import java.util.*;


/**
 * This class implements PKCS#1 v1.5 padding. Instances of it can perform
 * padding for encryption and unpad after decryption. There are also static
 * methods for padding of signatures.
 *
 * @author <a href="http://www.logi.org/">Logi Ragnarsson</a>
 * (<a href="mailto:logi@logi.org">logi@logi.org</a>)
 */
public class PadPKCS1v15
    implements Padding
{

    ///////////////////////////////////////////////////////////////////////
    // ALGORITHIM IDENTIFIER TABLE

    private static final HashMap ENCODED_HASH = new HashMap();

    private static final byte[] ENCODED_MD5  = Crypto.fromHexString(
                "3020300c06082a864886f70d020505000410"
            );

    private static final byte[] ENCODED_SHA1 = Crypto.fromHexString(
                "3021300906052b0e03021a05000414"
            );

    static {
        ENCODED_HASH.put("MD5",  ENCODED_MD5);
        ENCODED_HASH.put("SHA1", ENCODED_SHA1);
    }



    ///////////////////////////////////////////////////////////////////////
    // SIGNATURE PADDING


    /**
     * Encoding Method for Signature with Appendix. PKCS#1 v1.5, section 9.2.1.
     * Here, the message has already been hashed and we recieve the Fingerprint
     * object F. This also specifies the hash function to use.
     *
     * @param F The fingerprint to sign.
     * @param emLen The intended length of the encoded message.
     * @param random The randomness source to use for generating padding bytes.
     */
    public static byte[] EMSA_PKCS1_v1_5(Fingerprint F, int emLen)
        throws PaddingException
    {
        byte[] encodedPrefix = (byte[])ENCODED_HASH.get(F.getHashFunc());
        byte[] H = F.getBytes();
        if( emLen < encodedPrefix.length+H.length+10 ) {
            throw new PaddingException( "intended encoded message length too short" );
        }

        byte[] EM=new byte[emLen];
        int i=emLen;

        i-=H.length;
        System.arraycopy(H,0, EM,i, H.length);

        i-=encodedPrefix.length;
        System.arraycopy(encodedPrefix,0, EM,i, encodedPrefix.length);

        EM[i--] = 0x00;

        while(i>0) {
            EM[i--] = (byte)(0xff);
        }

        EM[0] = 0x01;

        return EM;
    }



    ///////////////////////////////////////////////////////////////////////
    // ENCRYPTION PADDING


    /**
     * Pad the last, perhaps partial, block of plaintext.
     *
     * @param plaintext The array holding plaintext data to pad.
     * @param off The offset of data within plaintext array.
     * @param len The length of data within plaintext array. This much be less
     *        than a single plaintext block.
     * @param key The key which will be used to encrypt the block.
     *
     * @returns The padded data, whose length will be a multiple of the
     * plaintext block size of the key.
     */
    public byte[] pad(byte[] plaintext, int off, int len, EncryptionKey key)
        throws PaddingException
    {
        int pbs = key.plainBlockSize();
        if( len>pbs-10 ) {
            throw new PaddingException( "Plaintext block too long for padding." );
        }
        byte[] padded = new byte[ pbs ];
        // The leading 0 byte is implicit in RSA since the plaintext block is a byte shorter than the modulus.
        int i=0;
        padded[i++] = 0x02;
        while( i<pbs-len-1 ) {
            padded[i++] = (byte)(Crypto.random.nextInt(255)+1);
        }
        padded[i++] = 0;
        System.arraycopy(plaintext, off, padded, i, len);
        return padded;
    }


    /**
     * Un-pad the last block of plaintext.
     *
     * @param padded The array holding padded plaintext data.
     * @param off The offset of data within padded array.
     * @param len The length of data within padded array.
     * @param key The key which will be used to decrypt the block.
     *
     * @returns The unpadded data, possibly zero bytes.
     */
    public byte[] unPad(byte[] plaintext, int off, int len, DecryptionKey key)
        throws PaddingException
    {
        int i=1;
        while( i<len-1 && plaintext[i]!=0 ) {
            i++;
        }
        // i points at the first zero, marking the beginning of plaintext, or at the last byte.
        if( (plaintext[0] != 0x02) || (i<9) || (i==len-1)) {
            throw new PaddingException( "Padding malformed or decryption unsuccessful." );
        }
        // plaintext[ ... | 0x02 | not 0x00 | 0x00 | plaintext | ...     ]
        //                 off    8+ bytes   i      i+1         off+len

        byte[] unpadded = new byte[ len-i-1 ];
        System.arraycopy( plaintext, i+1, unpadded,0, unpadded.length );
        return unpadded;
    }

}
