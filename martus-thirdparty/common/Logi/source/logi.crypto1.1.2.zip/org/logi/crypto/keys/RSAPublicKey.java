// Copyright (C) 1997-2001 Logi Ragnarsson

package org.logi.crypto.keys;

import org.logi.crypto.*;
import org.logi.crypto.sign.*;
import org.logi.crypto.padding.PadPKCS1v15;

import java.math.BigInteger;

import java.io.IOException;
import java.io.PrintWriter;


/**
 * An instance of this class handles a single public RSA key.<p>
 *
 * @author <a href="http://www.logi.org/">Logi Ragnarsson</a> (<a href="mailto:logi@logi.org">logi@logi.org</a>)
 */
public class RSAPublicKey
            extends K
            implements EncryptionKey, VerificationKey, BlindingKey, java.security.interfaces.RSAPublicKey
{


    /** The public RSA key exponent */
    protected BigInteger e;


    /** The RSA key modulus */
    protected BigInteger n;


    ///////////////////////////////////////////////////////////////////////
    // KEY MANAGEMENT CODE


    /**
     * Create a new public RSA key <code>(e,n)</code>.
     */
    public RSAPublicKey(BigInteger e, BigInteger n)
    {
        super();
        this.e = e;
        this.n = n;
    }


    /**
     * Used by Crypto.fromString when parsing a CDS.<p>

     * A valid CDS can be created by calling the toString() method.

     * @exception InvalidCDSException if the CDS is malformed.
     * @see org.logi.crypto.Crypto#fromString(String)
     */
    public static RSAPublicKey parseCDS(String[] param)
    throws InvalidCDSException
    {
        if(param.length!=2) {
            throw new InvalidCDSException("invalid number of parameters in the CDS RSAPublicKey(e,n) ");
        }
        return new RSAPublicKey(
                   new BigInteger(param[0],16),
                   new BigInteger(param[1],16)
               );
    }


    /** Return the size of the key modulo in bits. */
    public int getSize()
    {
        return n.bitLength();
    }


    /** The name of the algorithm is "RSA". */
    public String getAlgorithm()
    {
        return ("RSA");
    }


    /** Return the RSA exponent. */
    public BigInteger getPublicExponent()
    {
        return e;
    }


    /** Return the RSA modulus. */
    public BigInteger getModulus()
    {
        return n;
    }


    /**
     * Calculate the fingerprint for this key or the other in the
     * pair.
     */
    protected Fingerprint calcFingerprint(boolean other, String algorithm) throws InvalidCDSException
    {
        // The key-pair is uniquely defined by n, since it factors uniquely
        // into p and q which are used to calculate both exponents.
        HashState fs=HashState.create(algorithm);
        fs.update(n.toByteArray());
        if(other) {
            fs.update("pri");
        } else {
            fs.update("pub");
        }
        return fs.calculate();
    }




    /**
     * Return a CDS for this key.
     *
     * @see org.logi.crypto.Crypto#fromString
     */
    public String toString()
    {
        return "RSAPublicKey("+e.toString(16)+','+n.toString(16)+')';
    }


    /**
     * Print this object to out, indented with ind tabs, going down at most
     * rec levels of recursion. */
    public void prettyPrint(PrintWriter out, int ind, int rec)
    throws IOException
    {
        if(rec<0) {
            return;
        }
        for(int i=0; i<ind; i++) {
            out.print('\t');
        }
        out.println("RSAPublicKey(");

        for(int i=0; i<=ind; i++) {
            out.print('\t');
        }
        out.print(e.toString(16));
        out.println(",");

        for(int i=0; i<=ind; i++) {
            out.print('\t');
        }
        out.println(n.toString(16));

        for(int i=0; i<ind; i++) {
            out.print('\t');
        }
        out.print(")");
    }


    /** Return true iff the two keys are equivalent. */
    public boolean equals(Object o)
    {
        if (o==null) {
            return false;
        }
        if((o instanceof RSAPublicKey)) {
            RSAPublicKey other = (RSAPublicKey)o;
            return (this.e.equals(other.e) && this.n.equals(other.n));
        } else {
            return false;
        }
    }


    /**
     * Check if a key mathces this. This is true if this and key are a matched
     * pair of public/private keys. */
    public final boolean matches(Key key)
    {
        if ( !(key instanceof RSAPrivateKey) ) {
            return false;
        }
        RSAPrivateKey k = (RSAPrivateKey)key;
        return n.equals(k.n);
    }


    /**
     * Perform the RSA encryption transformation.
     */
    private BigInteger publicTransformation(BigInteger x)
    {
        return x.modPow(e,n);
    }



    ///////////////////////////////////////////////////////////////////////
    // CIPHER CODE

    /**
     * Returns the size of the blocks that can be encrypted in one call
     * to encrypt(). For RSA keys this depends on the size of the key.
     */
    public int plainBlockSize()
    {
        return (n.bitLength()-1)/8;
    }


    /**
     * Returns the size of the blocks that can be decrypted in one call
     * to decrypt(). For RSA keys this depends on the size of the key.
     */
    public int cipherBlockSize()
    {
        return plainBlockSize()+1;
    }


    /**
     * Encrypt one block of data. The plaintext is taken from
     * <code>source</code> starting at offset <code>i</code> and
     * ciphertext is written to <code>dest</code>, starting at
     * offset <code>j</code>.
     * <p>
     * The amount of data read and written will match the values returned
     * by <code>plainBlockSize()</code> and <code>cipherBlockSize()</code>.
     */
    public void encrypt(byte[] source, int i, byte[] dest, int j)
    {
        int plainSize = plainBlockSize();
        byte[] plain;

        if(i==0 && source.length==plainSize) {
            plain = source;
        } else {
            plain = new byte[plainSize];
            System.arraycopy(source,i, plain,0, plainSize);
        }

        byte[] cipher = publicTransformation(new BigInteger(1,plain)).toByteArray();

        if(cipher.length >= plainSize+1) {
            // The output is a full cipher block.
            System.arraycopy(cipher,cipher.length-(plainSize+1), dest, j, plainSize+1);
        } else {
            // The output is a bit on the short side
            System.arraycopy(cipher,0, dest, j+(plainSize+1)-cipher.length, cipher.length);
            for (int k=plainSize-cipher.length; k>=0; k--) {
                dest[j+k]=0;
            }
        }
    }



    ///////////////////////////////////////////////////////////////////////
    // SIGNATURE CODE


    /**
     * Returns the maximum size in bytes of the fingerprint
     * that can be signed. */
    public int signBlockSize()
    {
        // plain block - bytes used for algorithm ID, DER encoding and mninimum padding.
        return plainBlockSize()-29;
    }


    /**
     * Returns the length of the signature in bytes. */
    public int signatureSize()
    {
        return cipherBlockSize();
    }


    /**
     * Verify a Signature on a Fingerprint with a public key.
     * <p>
     * The method returns true iff <code>s</code> is a signature for
     * <code>fp</code> created with the mathcing private key.
     *
     * @exception KeyException if this is not a public key
     */
    public boolean verify(Signature s, Fingerprint fp)
    throws CryptoException
    {
        BigInteger signature = new BigInteger(1,s.getBytes());
        byte[] plain = publicTransformation(signature).toByteArray();
        byte[] hash = fp.getBytes();

        return equalSub(
                   plain, plain.length-hash.length,
                   hash, 0,
                   hash.length
               );
    }



    ///////////////////////////////////////////////////////////////////////
    // BLIND SIGNATURE CODE


    /**
     * Create a new blinding factor suitable for blinding a fingerprint
     * before being signed with the private key in the pair.
     */
    public BlindingFactor createBlindingFactor()
    {
        int length = n.bitLength();
        BigInteger factor=new BigInteger(length, random);
        while(factor.compareTo(n)>=0) {
            factor=new BigInteger(length, random);
        }
        return new RSABlindingFactor(factor);
    }


    /**
     * Blind a fingerprint with a public key and the given blinding factor
     * in preparation for blindly signing the fingerprint with the private
     * key.

     * @exception KeyException if you try to blind with a private key
     * @exception KeyException if the BlindingFactor is not an RSABlindingFactor
     */
    public BlindFingerprint blind(Fingerprint fp, BlindingFactor bf)
    throws KeyException
    {
        if(! (bf instanceof RSABlindingFactor)) {
            throw new KeyException("The blinding factor is not for RSA keys.");
        }
        RSABlindingFactor rbf = (RSABlindingFactor)bf;

        // copy bytes from fp to bigbuf
        byte[] buf=fp.getBytes();
        byte[] bigBuf=new byte[plainBlockSize()];
        if(bigBuf.length<buf.length) {
            throw new KeyException("This key is to short to sign this hash.");
        }
        System.arraycopy(buf,0, bigBuf,bigBuf.length-buf.length, buf.length);

        // Pad with random bytes
        int i=bigBuf.length-buf.length-1;
        int k=i%8;
        i=(i/8)*8;
        writeBytes(random.nextLong(), bigBuf, i, k);
        for(i=i-8; i>=0; i-=8) {
            writeBytes(random.nextLong(), bigBuf, i, 8);
        }
        BigInteger f=new BigInteger(1,bigBuf);

        f=f.multiply(publicTransformation(rbf.getFactor())).mod(n);

        return new BlindFingerprint(
                   fp.getHashFunc(),
                   "RSA",
                   trimLeadingZeroes(f.toByteArray())
               );
    }


    /**
     * Unblind a blind signature using the same blinding factor that was
     * used to blind the original fingerprint.

     * @exception KeyException if there are problems, depending on the implementing class.
     */
    public Signature unBlind(BlindSignature bs, BlindingFactor bf)
    throws KeyException
    {
        if(! (bf instanceof RSABlindingFactor)) {
            throw new KeyException("The blinding factor is not for RSA keys.");
        }
        RSABlindingFactor rbf = (RSABlindingFactor)bf;
        BigInteger s = new BigInteger(1,bs.getBytes());
        s=s.multiply(rbf.getFactor().modInverse(n)).mod(n);
        return new Signature(
                   bs.getHashFunc(),
                   trimLeadingZeroes(s.toByteArray())
               );
    }


}
