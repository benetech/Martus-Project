// Copyright (C) 1998-2000 Logi Ragnarsson

package org.logi.crypto.sign;
import org.logi.crypto.*;

import java.io.*;

/**
 * This class stores a blinded digital signature. See the BlindFingerprint
 * class for details.
 
 * @see org.logi.crypto.sign.BlindFingerprint
 * @version 1.1.0
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 *         (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class BlindSignature extends Signature
{

    protected String blindFunc;

    /**
     * Create a new BlindSignature object. It contains the signature
     * <code>s</code> which was generated from a fingerprint using
     * the specified hash function.
     */
    public BlindSignature(String hashFunc, String blindFunc, byte[] s)
    {
        super(hashFunc, s);
        this.blindFunc=blindFunc;
    }

    /**
     * Used by Crypto.fromString when parsing a CDS. A valid CDS can be
     * created by calling the toString() method.

     * @exception InvalidCDSException if the CDS is malformed.
     * @see org.logi.crypto.Crypto#fromString(String)
     */
    public static Signature parseCDS(String[] param) throws InvalidCDSException
    {
        if(param.length!=3)
            throw new InvalidCDSException("invalid number of parameters in the CDS BlindSignature(hashFunc,blindFunc,signature)");
        return new BlindSignature(param[0], param[1], fromHexString(param[2]));
    }

    /**
     * Return the name of the function used to blind the fingerprint before
     * signing. */
    public String getBlindFunc()
    {
        return blindFunc;
    }

    /**
     * Return a CDS for this object.
     */
    public String toString()
    {
        StringBuffer sb=new StringBuffer();
        sb.append("BlindSignature(");
        sb.append(hashFunc==null ? "null" : hashFunc);
        sb.append(',');
        sb.append(blindFunc==null ? "null" : blindFunc);
        sb.append(',');
        sb.append(s==null ? "null" : hexString(s));
        sb.append(')');
        return sb.toString();
    }

    /**
     * Print this object to out, indented with ind tabs, going down at most
     * rec levels of recursion. */
    public void prettyPrint(PrintWriter out, int ind, int rec) throws IOException
    {
        if(rec<0)
            return;
        for(int i=0; i<ind; i++)
            out.print('\t');
        out.println("BlindSignature(");

        for(int i=0; i<=ind; i++)
            out.print('\t');
        out.print(hashFunc);
        out.println(",");

        for(int i=0; i<=ind; i++)
            out.print('\t');
        out.print(hexString(s));
        out.println();

        for(int i=0; i<ind; i++)
            out.print('\t');
        out.print(")");
    }

}
