// Copyright (C) 1998-2001 Logi Ragnarsson

package org.logi.crypto.modes;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.padding.*;

import java.util.Random;

/**
 * Electronic Codebook Mode simply encrypts each block of plaintext
 * independently. It is not as secure as for example CBC mode.
 * <p>
 * A padding engine can be passed to the constructor of the EncryptECB object
 * to allow the encryption of data which is not a whole multiple of plaintext
 * blocks. If no padding engine is given, then the padding used depends on the
 * key class being used.
 * <p>
 * If the key implements the CipherKey interface, which makes it a key for a
 * symmetric cipher, then no padding is parformed. It is upt to the user to
 * ensure that there is a whole multiple of plaintext blocks (this can, or
 * course, by specifying a padding engine in the constructor). Otherwise PKCS#1
 * padding is used, which is appropriate for RSA and Diffie-Hellman/El-Gamal.
 *
 * @see org.logi.crypto.modes.DecryptECB
 *
 * @author <a href="http://www.logi.org/">Logi Ragnarsson</a>
 * (<a href="mailto:logi@logi.org">logi@logi.org</a>)
 */
public class EncryptECB
    extends EncryptMode
{

    /** The key to use for encryption. */
    private EncryptionKey key;

    /** The padding engine to use on the last block. */
    private Padding padding;

    /** Input block size and output block size. */
    private int pbs;
    private int cbs;

    /**
     * <code>buffer[0..bufPos-1]</code> is data waiting to be part of a
     * full block. */
    private byte[] buffer;
    private int bufPos;


    /**
     * Create a new ECB-mode encrypt session.
     *
     * @param key The key to use for decryption.
     * @param padding The padding engine to use.
     */
    public EncryptECB(EncryptionKey key, Padding padding)
    {
        this.padding = padding;
        try {
            setKey(key);
        } catch (CryptoException e) {
            // Not thrown on first call.
        }
    }


    /**
     * Create a new ECB-mode encrypt session with default padding.
     *
     * @param key The key to use for decryption.
     */
    public EncryptECB(EncryptionKey key)
    {
        try {
            setKey(key);
        } catch (CryptoException e) {
            // Not thrown on first call.
        }
    }


    /**
     * Create a new ECB-mode encrypt session with no key. No encryption can be
     * performed until the <code>setKey()</code> method has been called.
     *
     * @param padding The padding engine to use.
     */
    public EncryptECB(Padding padding)
    {
        this.padding = padding;
    }


    /**
     * Create a new ECB-mode encrypt session with no key and default padding.
     * No encryption can be performed until the <code>setKey()</code>
     * method has been called.  */
    public EncryptECB()
    {
        this.padding = null;
    }


    /** Return the key used for encryption. */
    public EncryptionKey getKey()
    {
        return key;
    }

    /** Set the key to use for encryption. Do not call this method
     * when there may be data in the internal buffer.
     *
     * @exception CryptoException if there is data in the internal buffer
     * which should be encrypted with the old key. */
    public synchronized void setKey(EncryptionKey key)
    throws CryptoException
    {
        if(bufPos!=0) {
            throw new CryptoException("Internal buffer not empty.");
        }
        this.key=key;
        pbs = key.plainBlockSize();
        cbs = key.cipherBlockSize();
        buffer = new byte[key.plainBlockSize()];
        if( padding==null ) {
            if( key instanceof CipherKey ) {
                this.padding = new PadNone();
            } else {
                this.padding = new PadPKCS1v15();
            }
        }
    }

    /**
     * Return the size of the blocks of plaintext encrypted by this object.
     */
    public int plainBlockSize()
    {
        return key.plainBlockSize();
    }

    /**
     * Pads the internal buffer, encrypts it and returns the
     * ciphertext. */
    public synchronized byte[] flush()
        throws PaddingException
    {
        byte[] padded = padding.pad( buffer, 0, bufPos, key );
        if( padded.length==0 ) {
            return padded;
        }
        if( padded.length!=pbs ) {
            throw new PaddingException( "Padding engine returned "+padded.length+" bytes, but the plain block size is "+pbs );
        }

        byte[] dest = new byte[ cbs ];
        key.encrypt( padded,0, dest,0 );

        return dest;
    }

    /**
     * Send bytes to the EncryptECB object for encryption.
     * <p>
     * Encrypt <code>length</code> bytes from <code>source</code>,
     * starting at <code>i</code> and return the ciphertext. Data is
     * encrypted in blocks, so only whole blocks of ciphertext
     * are written to <code>dest</code>. Any remaining plaintext will be
     * stored and prepended to <code>source</code> in the next call to
     * <code>encrypt</code>.
     */
    public synchronized byte[] encrypt(byte[] source, int i, int length)
    {
        int blocks = (bufPos+length)/pbs;
        byte[] dest = new byte[blocks*cbs];
        int j=0;    // dest[0..j-1] is ciphertext

        if( bufPos>0 ) {
            // We have unencrypted data in the buffer
            int n=Math.min( length, buffer.length-bufPos );
            System.arraycopy( source,i, buffer,bufPos, n );
            bufPos+=n;
            i+=n;
            length-=n;
            blocks--;
            if( bufPos==buffer.length ) {
                // We've filled the buffer
                key.encrypt( buffer,0, dest,0 );
                j += cbs;
                bufPos=0;
            } else {
                return dest;  // can't even fill one block...
            }
        }
        int ii=i;

        // Encrypt entire blocks
        for( int b=0; b<blocks; b++ ) {
            key.encrypt( source, i, dest, j );
            i += pbs;
            j += cbs;
        }

        // Put possible incomplete block in the buffer
        bufPos = length-(i-ii);
        if( bufPos!=0 ) {
            System.arraycopy( source,i, buffer,0, bufPos );
        }
        return dest;
    }

}
