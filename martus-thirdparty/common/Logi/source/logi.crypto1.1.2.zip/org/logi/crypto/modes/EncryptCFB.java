// Copyright (C) 1998,2000 Logi Ragnarsson

package org.logi.crypto.modes;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;

import java.util.Random;

/**
 * This class implements 8-bit Cipherblock FeedBack mode which encrypts
 * a whole block for each plaintext character. This makes it much slower
 * than the ECB, CBC and OFB modes.<p>
 
 * CFB mode is also inherently incompatible with probabilistic encryption
 * algorithms such as ElGamal (implemented in the DHKey class) since it
 * relies on the same keystream being gengerated by the encrypting and
 * decrypting processes.
 
 * @see org.logi.crypto.modes.DecryptCFB
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class EncryptCFB extends EncryptMode
{

    /** The key to use for encryption. */
    private EncryptionKey key;

    /** Input block size and output block size. */
    private int ibs;
    private int obs;

    /** CFB queue.*/
    private byte[] queue;

    /**
     * Create a new CBF-mode encrypt session with the specified key.
     *
     * @exception KeyException if key is a public key.
     */
    public EncryptCFB(EncryptionKey key) throws KeyException
    {
        setKey(key);
    }

    /**
     * Create a new CBF-mode encrypt session with no key. No
     * encryption can be performed until the <code>setKey()</code>
     * method has been called.  */
    public EncryptCFB()
    {}

    /** Return the key used for encryption. */
    public EncryptionKey getKey()
    {
        return key;
    }

    /**
     * Set the key to use for encryption.
     *
     * @exception KeyException if key is a public key.
     */
    public synchronized void setKey(EncryptionKey key)
    throws KeyException
    {
        if( !(key instanceof CipherKey) ) {
            throw new KeyException( "a non-symmetric key passed to CFB-mode" );
        }
        this.key=key;
        ibs=key.plainBlockSize();
        obs=key.cipherBlockSize();
        queue=null;
    }

    /**
     * Return the size of the blocks of plaintext encrypted by this object.
     */
    public int plainBlockSize()
    {
        return 1;
    }

    /**
     * Pads the internal buffer, encrypts it and returns the ciphertext.
     * Since CBF mode doesn't use an internal buffer, an empty array is
     * returned.
     */
    public synchronized byte[]
    flush()
    {
        return new byte[0];
    }

    /**
     * Send bytes to the EncryptCFB object for encryption.
     * <p>
     * Encrypt <code>length</code> bytes from <code>source</code>,
     * starting at <code>i</code> and return the ciphertext.
     */
    public synchronized byte[]
    encrypt(byte[] source, int i, int length)
    {
        byte[] dest;
        int destPos=0;
        if(queue==null) {
            // We need an IV now
            queue = new byte[ibs];
            random.nextBytes(queue);
            dest = new byte[length+ibs];
            System.arraycopy(queue,0, dest,0, ibs);
            destPos=ibs;
        } else {
            // Create 'small' output buffer
            dest = new byte[length];
        }

        int end=i+length;
        byte[] buf=new byte[obs];
        while(i<end) {
            key.encrypt(queue,0, buf,0);
            dest[destPos]=(byte)(source[i] ^ buf[0]);
            System.arraycopy(queue,1, queue,0, ibs-1);
            queue[ibs-1]=dest[destPos];
            i++;
            destPos++;
        }

        return dest;
    }

}
