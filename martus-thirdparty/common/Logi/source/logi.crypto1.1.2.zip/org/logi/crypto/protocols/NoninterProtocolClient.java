// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.protocols;

/**
 * This interface is implemented by classes for the client portion of a
 * non-interactive protocol.
 * <p>
 * In this context, the party which initiates the protocol is considered the
 * client. Non-interactive means that the client does not need to recieve any
 * information from the server, so the protocol can be used off-line.
 * <p>
 * A non-interactive protocol can of course also be used on-line and is
 * therefore also considered an Interactive protocol. This is why the
 * NoninterProtocol interfaces extend the InterProtocol interfaces.
 *
 * @see org.logi.crypto.protocols.NoninterProtocolServer
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public interface NoninterProtocolClient extends InterProtocolClient
    {}
