// Copyright (C) 1998-2000 Logi Ragnarsson

package org.logi.crypto.protocols;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.modes.*;
import org.logi.crypto.sign.*;
import org.logi.crypto.random.Seedable;

/**
 * Exchange keys by sending an encrypted key from this class to the
 * corresponding EncryptedKeyExServer.
 *
 * @see org.logi.crypto.protocols.EncryptedKeyExServer
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>) */
public class EncryptedKeyExClient
    extends Crypto
    implements NoninterKeyExClient
{

    protected boolean keyDecided=false;

    protected EncryptionKey key;   // key used to encrypt session-key
    protected SigningKey signKey;  // key used to sign session-key
    protected Key sessionKey;      // the session key


    /**
     * Create a new EncryptedKeyExClient object. It uses
     * <code>key</code> to encrypt <code>sessionKey</code> and then
     * sends it to the server.  */
    public EncryptedKeyExClient(EncryptionKey key, Key sessionKey)
    {
        this.key=key;
        this.sessionKey=sessionKey;
    }


    /**
     * Create a new EncryptedKeyExClient object. It uses
     * <code>key</code> to encrypt <code>sessionKey</code> and then
     * sends it to the server.
     * <p>
     * If <code>signKey</code> is not <code>null</code>, then the
     * session key will be signed with this key.
     */
    public EncryptedKeyExClient(EncryptionKey key, SigningKey signKey, Key sessionKey)
    {
        this.key=key;
        this.signKey=signKey;
        this.sessionKey=sessionKey;
    }


    /**
     * Returns the key if it has been decided upon,
     * or <code>null</code> otherwise.
     */
    public Key sessionKey()
    {
        return keyDecided ? sessionKey : null;
    }

    /** Returns true iff this end of the protocol i completed. */
    public boolean completed()
    {
        return keyDecided;
    }


    /**
     * Returns the maximum expected size of a message for this protocol. */
    public int maxMessageSize()
    {
        return 65536;
    }


    /**
     * Get the next message in the protocol.
     *
     * <p> <code>received</code> is the last message received form the server
     * and has not yet been sent to the client.
     *
     * <p> The returned value is the next message to send to the
     * server or null if no more messages need to be sent and the
     * protocol is terminated.
     *
     * @exception CryptoProtocolException if a problem arises with the
     * protocol.  */
    public byte[] message(byte[] received)
        throws CryptoProtocolException
    {
        if(received!=null) {
            throw new CryptoProtocolException("A non-interactive key-exchange client should not receive messages.");
        }

        byte[] plain = sessionKey.toString().getBytes();
        EncryptECB em = new EncryptECB(key);
        byte[] c1 = em.encrypt(plain,0,plain.length);
        byte[] c2;
        try {
            c2 = em.flush();
        } catch (org.logi.crypto.padding.PaddingException pex) {
            throw new CryptoProtocolException( "Caught "+pex.toString() );
        }

        byte[] message;
        if(signKey==null) {
            message = new byte[c1.length+c2.length+8];
            writeBytes(message.length, message,0, 4);
            // message = [ sign-idx |                |               ]
            //             ^          ^                ^               ^
            //             0          4                8               signIdx
        }
        else {
            try {
                byte[] signature = signKey.sign(Fingerprint.create(plain, "SHA1")).getBytes();
                message = new byte[c1.length+c2.length+signature.length+8];
                int signIdx = 8+c1.length+c2.length;
                writeBytes(signIdx, message,0, 4);
                System.arraycopy(signature,0, message,signIdx, signature.length);
                // message = [ sign-idx |                |               | signature ]
                //             ^          ^                ^               ^
                //             0          4                8               signIdx
            }
            catch (InvalidCDSException f) {
                throw new CryptoCorruptError(f.getMessage());
            }
            catch (CryptoException e) {
                throw new CryptoProtocolException(e.getMessage());
            }
        }
        writeBytes(plain.length, message,4, 4);
        System.arraycopy(c1,0, message,8          , c1.length);
        System.arraycopy(c2,0, message,8+c1.length, c2.length);

        keyDecided=true;

        // message = [ sign-idx | plain key-size | encrypted key | signature ]
        //             ^          ^                ^               ^
        //             0          4                8               signIdx
        //
        // The signature may be an empty string, meaning no signature.
        return message;
    }

}
