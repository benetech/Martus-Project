// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.protocols;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;

import java.math.BigInteger;

/**
 * Ancestor of QRAuth classes.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
class QRAuth
    extends Crypto
{

    /** The secret key. */
    protected CipherKey key;

    /** The random number chosen by the other. */
    protected byte[] r;

    protected boolean completed;

    /**
     * Creates a new QRAuth object with the specified secret
     * <code>key</code>.
     */
    public QRAuth(CipherKey key)
    {
        this.key=key;
    }

    /** Returns true iff this end of the protocol is completed. */
    public boolean completed()
    {
        return completed;
    }

    /** Add one to the number stored in a[0..a.length-1]. */
    protected static void addOne(byte[] a)
    {
        int i=a.length-1;
        a[i]++;
        while( (i>=0) && (a[i]==0) )
            a[i++]++;
    }

    /**
     * Returns the maximum expected size of a message for this protocol. */
    public int maxMessageSize()
    {
        return 65536;
    }

}
