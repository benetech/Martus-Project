// Copyright (C) 1999-2001 Logi Ragnarsson

package org.logi.crypto.keys;
import org.logi.crypto.*;
import org.logi.crypto.sign.*;

import java.math.BigInteger;
import java.io.*;


/**
 * This object holds one Diffie-Hellman key. They can be used for
 * Diffie-Hellman key-exchange with the DHKeyExNoninter and related
 * classes or directly for encryption and signatures, in which case
 * it uses the ElGamal algorithm.
 * <p>
 * The modulus and generator for the group from which the key is chosen
 * are fixed for a given key-size. They are pre-calculated for a few
 * bit-sizes, but take long to claculate for others.
 * <p>
 * The CDS for a Diffie-Hellman key is <code>DHKey(x,g,m,pub)</code>
 * for a public key or <code>DHKey(x,g,m,pri)</code> for a private
 * key. In both cases <code>x</code>,<code>g</code> and <code>m</code> are
 * hexadecimal numbers.
 *
 * @see org.logi.crypto.protocols.DHKeyExNoninter
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class DHPublicKey
    extends K
    implements EncryptionKey, VerificationKey
{


    /** Public key. */
    private BigInteger y;

    /** Generator */
    private BigInteger g;

    /** Modulus */
    private BigInteger m;



    ///////////////////////////////////////////////////////////////////////
    // KEY MANAGEMENT CODE


    /**
     * Create a new Diffie-Hellman key object. An object is created for
     * <code>x</code> in the group modulo <code>m</code> with generator
     * <code>g</code>. It is a private key iff </code>pri<code> is
     * <code>true</code>.
     */
    public DHPublicKey(BigInteger y, BigInteger g, BigInteger m)
    {
        this.g=g;
        this.m=m;
        this.y=y;
    }

    /**
     * Used by Crypto.fromString when parsing a CDS.<p>

     * A valid CDS can be created by calling the toString() method.

     * @exception InvalidCDSException if the CDS is malformed.
     * @see org.logi.crypto.Crypto#fromString(String)
     */
    public static DHPublicKey parseCDS(String[] param)
    throws InvalidCDSException
    {
        if(param.length!=3) {
            throw new InvalidCDSException("invalid number of parameters in the CDS DHPublicKey(y,h,m)");
        }

        return new DHPublicKey(
                   new BigInteger(param[0],16),
                   new BigInteger(param[1],16),
                   new BigInteger(param[2],16)
               );
    }


    /**
     * Return the "size" of the key. This is a (fairly inaccurate) measure
     * of how difficult it is to break and is heavily dependant on the
     * algorithm used.
     */
    public int getSize()
    {
        return m.bitLength();
    }


    /**
     * The name of the algorithm is "Diffie-Hellman".
     */
    public String getAlgorithm()
    {
        return "Diffie-Hellman";
    }


    /**
     * Return y.
     */
    public BigInteger getY()
    {
        return y;
    }


    /**
     * Return the modulus for this key.
     */
    public BigInteger getM()
    {
        return m;
    }


    /**
     * Return the generator for this key.
     */
    public BigInteger getG()
    {
        return g;
    }


    /**
     * Calculate the fingerprint for this key or the other in the pair.
     */
    protected Fingerprint calcFingerprint(boolean other, String algorithm)
    throws InvalidCDSException
    {
        // The key-pair is uniquely defined by the public key, since the
        // private key is "merely" the discrete log of the public key.
        HashState fs=HashState.create(algorithm);
        fs.update(y.toByteArray());
        fs.update(m.toByteArray());
        if(other) {
            fs.update("pri");
        } else {
            fs.update("pub");
        }
        return fs.calculate();
    }


    /**
     * Return true iff the two keys are equivalent.
     */
    public final boolean equals(Object o)
    {
        if (o==null) {
            return false;
        }
        if ( !(o instanceof DHPublicKey) ) {
            return false;
        }
        DHPublicKey other = (DHPublicKey)o;
        return (this.y.equals(other.y) &&
                this.m.equals(other.m) &&
                this.g.equals(other.g)
               );
    }


    /**
     * Check if a key mathces this. This is true if this and key are a matched
     * pair of public/private.
     */
    public boolean matches(Key key)
    {
        if(key instanceof DHPrivateKey) {
            return this.equals(((DHPrivateKey)key).getPublic());
        } else
            return false;
    }


    /**
     * Return a CDS for this key.
     */
    public String toString()
    {
        StringBuffer sb=new StringBuffer();
        sb.append("DHPublicKey(");
        sb.append(y.toString(16));
        sb.append(',');
        sb.append(g.toString(16));
        sb.append(',');
        sb.append(m.toString(16));
        sb.append(')');
        return sb.toString();
    }


    /**
     * Print this object to out, indented with ind tabs, going down at most
     * rec levels of recursion. */
    public void prettyPrint(PrintWriter out, int ind, int rec)
        throws IOException
    {
        if(rec<0) {
            return;
        }
        for(int i=0; i<ind; i++)
            out.print('\t');
        out.println("DHPublicKey(");

        for(int i=0; i<=ind; i++)
            out.print('\t');
        out.print(y.toString(16));
        out.println(",");

        for(int i=0; i<=ind; i++)
            out.print('\t');
        out.print(g.toString(16));
        out.println(",");

        for(int i=0; i<=ind; i++)
            out.print('\t');
        out.print(m.toString(16));
        out.println();

        for(int i=0; i<ind; i++)
            out.print('\t');
        out.print(")");
    }



    ///////////////////////////////////////////////////////////////////////
    // CIPHER CODE (ElGamal algorithm)


    /**
     * Returns the size of the blocks that can be encrypted in one call
     * to encrypt(). For ElGamal keys this depends on the size of the key.
     */
    public int plainBlockSize()
    {
        return (m.bitLength()-1)/8;
    }


    /**
     * Returns the size of the blocks that can be decrypted in one call
     * to decrypt(). For ElGamal keys this depends on the size of the key.
     */
    public int cipherBlockSize()
    {
        return 2*plainBlockSize()+2;
    }


    /**
     * Encrypt one block of data. The plaintext is taken from
     * <code>source</code> starting at offset <code>i</code> and
     * ciphertext is written to <code>dest</code>, starting at
     * offset <code>j</code>.
     * <p>
     * The amount of data read and written will match the values returned
     * by <code>plainBlockSize()</code> and <code>cipherBlockSize()</code>.
     */
    public void encrypt(byte[] source, int i, byte[] dest, int j)
    {
        BigInteger k;
        BigInteger m1=m.subtract(ONE);
        do {
            k=new BigInteger(m.bitLength(),random);
        } while (k.compareTo(m)>=0 || !k.gcd(m1).equals(ONE));
        // k is a random element in Z_m relatively prime to m-1.

        int pbs = plainBlockSize();
        byte[] t = new byte[pbs];
        System.arraycopy(source,i, t,0, plainBlockSize());
        BigInteger M = new BigInteger(1,t);

        BigInteger a = g.modPow(k,m);
        BigInteger b = y.modPow(k,m).multiply(M).mod(m);

        int size=pbs+1;

        t=a.toByteArray();
        if(t.length>=size) {
            // t is either the exact length or has a sign bit in front which
            // may be discarded.
            System.arraycopy(t, t.length-size, dest,j, size);
        } else {
            // t is short.
            for(int ii=j; ii<j+size-t.length; ii++) // zero out unused space
                dest[ii]=0;
            System.arraycopy(t,0, dest, j+size-t.length, t.length);
        }

        t=b.toByteArray();
        if(t.length>=size) {
            // t is either the exact length or has a sign bit in front which
            // may be discarded.
            System.arraycopy(t,t.length-size, dest,j+size, size);
        } else {
            // t is short.
            for(int ii=j+size; ii<j+2*size-t.length; ii++) // zero out unused space
                dest[ii]=0;
            System.arraycopy(t,0, dest, j+2*size-t.length, t.length);
        }
    }



    ///////////////////////////////////////////////////////////////////////
    // SIGNATURE CODE (ElGamal algorithm)


    /**
     * Returns the maximum size in bytes of the fingerprints
     * that can be signed. */
    public int signBlockSize()
    {
        return (m.bitLength()-1)/8;
    }


    /**
     * Returns the length of a signature in bytes. */
    public int signatureSize()
    {
        return 2*signBlockSize()+2;
    }


    /**
     * Verify a Signature on a Fingerprint with a public key.
     * <p>
     * The method returns true iff <code>s</code> is a signature for
     * <code>fp</code> created with the mathcin private key.
     *
     * @exception KeyException if this is not a public key
     */
    public boolean verify(Signature s, Fingerprint fp)
    throws KeyException
    {
        int size=(m.bitLength()+7)/8;
        byte[] sb = s.getBytes();
        if(sb.length!=2*size)
            return false;

        byte[] t = new byte[size];

        System.arraycopy(sb,0,   t,0, size);
        BigInteger a = new BigInteger(1,t);

        System.arraycopy(sb,size, t,0, size);
        BigInteger b = new BigInteger(1,t);

        BigInteger M = new BigInteger(1,fp.getBytes());

        BigInteger l = y.modPow(a,m).multiply(a.modPow(b,m)).mod(m);
        BigInteger r = g.modPow(M,m);
        return l.equals(r);
    }

}
