// Copyright (C) 1998-2001 Logi Ragnarsson

package org.logi.crypto.modes;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.padding.*;

/**
 * Uninteresting implementation detail.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 *         (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
abstract class EncryptMode
    extends Crypto
    implements EncryptSession
{

    /**
     * Equivalent to calling <code>encrypt(source,i,length)</code>
     * followed by <code>flush()</code>.
     */
    public byte[] flush( byte[] source, int i, int length )
        throws PaddingException
    {
        byte[] e1 = encrypt( source,i,length );
        byte[] e2 = flush();
        if( e2.length==0 ) {
            return e1;
        }
        byte[] r = new byte[ e1.length+e2.length ];
        System.arraycopy( e1,0, r,0        , e1.length );
        System.arraycopy( e2,0, r,e1.length, e2.length );
        return r;
    }

    public void close()
    {}

    public void finalize()
    {
        close();
    }

}
