// Copyright (C) 2000-2001 Logi Ragnarsson

package org.logi.crypto.modes;

/**
 * Subclasses of Producer can run in their own thread producing bytes which
 * can be used by a consumer thread. The produced bytes are stored in a
 * fixed-size buffer, the size of which is specified when the object is
 * created.

 * Concrete implementations must implement the method <blcokquote><tt>
 *   public abstract void calculate(byte[] buf);
 * </tt></blockquote> to fill the array buf with the buf.length bytest
 * of the data to be buffered.

 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
abstract class Producer
//    extends Crypto
    implements Runnable
{

    // Show (a lot of) thread-debug messages
    private static final boolean DEBUG=false;

    private volatile byte[][] buffers;
    private volatile int consuming;  // The consumer is using or is about to start using buffers[consuming]
    private volatile int filling;    // The produceer is using or is about to start using buffers[filling]

    /** true if the thread should terminate as soon as possible. */
    private volatile boolean terminating=false;

    private Thread thread;

    /**
     * Create a new Producer with 4 sub-buffers each holding bufSize bytes. */
    protected Producer(int bufSize)
    {
        if(DEBUG)
            System.err.println("Creating a Producer with quart-buffers of "+bufSize+" bytes");
        buffers = new byte[4][bufSize];
        consuming = 3;
        filling = 0;
        thread = new Thread(this);
        thread.setDaemon(true);
    }

    /**
     * Terminate the producer thread. */
    public synchronized void kill()
    {
        if(DEBUG)
            System.err.println("Asking producer to terminate");
        terminating=true;
        notify();
    }

    /**
     * Start the producer thread. This should be called by a sub-class when
     * it is ready to start calculating. This will probably be on the last
     * line of a constructor. */
    protected void start()
    {
        thread.start();
    }

    /**
     * Return the next array of bytes calculated by the producer. The thread
     * calling this method will have exclusive access to the returned array
     * until the next call to this method, after which the producer thread
     * may fill it with new bytes. */
    public byte[] nextBuffer()
    {
        int c = (consuming+1)%4;
        synchronized(this) {
            while(c==filling)
                try {
                    if (DEBUG)
                        System.err.println("C: Waiting for lock on "+c);
                    wait();
                } catch (InterruptedException ie) {}
            consuming=c;
            if (DEBUG)
                System.err.println("C: Got lock on "+c);
            notify();
        }
        return buffers[c];
    }

    /**
     * Repeatedly call calculate(byte[]) on each of the sub-buffers,
     * respecting the locking semantics of nextBuffer(). */
    public void run()
    {
        if (DEBUG)
            System.err.println("P: Bprn with lock on "+0+" ("+consuming+")");
        while(!terminating) {
            calculate(buffers[filling]);
            int f = (filling+1)%4;
            synchronized(this) {
                while(f==consuming  && !terminating)
                    try {
                        if (DEBUG)
                            System.err.println("P: Waiting for lock on "+f);
                        wait();
                    } catch (InterruptedException ie) {}
                filling=f;
                if (DEBUG)
                    System.err.println("P: Got lock on "+f+" ("+consuming+")");
                notify();
            }
        }
        if(DEBUG)
            System.err.println("Producer is terminating");
    }

    /**
     * Fills buf with newly produced bytes. */
    public abstract void calculate(byte[] buf);

}
