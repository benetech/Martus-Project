// Copyright (C) 1998-2001 Logi Ragnarsson

package org.logi.crypto.io;

import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.modes.*;
import org.logi.crypto.protocols.*;

import java.io.*;

/**
 * This OutputStream encrypts everything written to it using the specified
 * EncryptSession. It optionally first executes a non-interactive
 * key-exchange protocol.
 * <p>
 * The DecryptStream must be initialized with a NoninterKeyExServer
 * object complementing the NoninterKeyExClient object used in the
 * EncryptStream and a DecryptMode object complementing the EncryptSession
 * object used in the DecryptStream.
 *
 * @see org.logi.crypto.io.DecryptStream
 * @see org.logi.crypto.modes.EncryptSession
 *
 * @author <a href="http://www.logi.org/">Logi Ragnarsson</a>
 * (<a href="mailto:logi@logi.org">logi@logi.org</a>)
 */
public class EncryptStream
    extends FilterOutputStream
{

    private EncryptSession emode;

    /**
     * Create a new EncryptStream. Ciphertext is written to <code>out</code>,
     * <code>emode</code> is used for encryption and if <code>kex</code>
     * is not null it will be used to generate a session key and/or send it
     * to the server. See the various key-exchange client classes for
     * details.
     * <p>
     * Note that if <code>kex</code> is not null, it controls which
     * session key is used and <code>emode</code> receives the session key
     * when it has been decided. If <code>kex</code> is null, then
     * <code>emode</code> must be initialized with a key, and the same symmetric
     * key or matching asymmetric key must be used on the server.
     *
     * @exception CryptoProtocolException if a problem arises with the key-exchange protocol.
     * @exception IOException if problems arise with the underlying OutputStream.  */
    public EncryptStream(OutputStream out, NoninterKeyExClient kex, EncryptSession emode)
        throws CryptoProtocolException, IOException
    {
        super(out);
        this.emode = emode;

        if(kex!=null) {
            // Let's do key-exchange
            execute(kex, false);
            try {
                CipherKey key=(CipherKey)kex.sessionKey();
                if(key==null) {
                    throw new CryptoProtocolException("A non-interactive protocol should only need one message.");
                }
                emode.setKey(key);
            } catch (ClassCastException cce) {
                throw new CryptoProtocolException("The key-exchange protocol proposes to use a non-cipher key for encryption.");
            } catch (CryptoException ke) {
                throw new CryptoProtocolException(ke.getMessage());
            }
        }
        if(emode.getKey()==null) {
            throw new CryptoProtocolException("No key specified or exchanged");
        }
    }


    /**
     Return the key used for encrypting this stream, or null if one has not
     been specified. */
    public EncryptionKey getKey()
    {
        if(emode==null) {
            return null;
        }
        return emode.getKey();
    }


    /**
     * Re-key the EncryptSession used by this DecryptStream. This induces a
     * flush of the stream.
     *
     * @exception IOException if there is a low-level problem.
     * @exception CryptoException if the internal buffer in the EncryptSession
     * is not empty. */
    public void setKey(CipherKey key)
        throws IOException, CryptoException
    {
        flush();
        emode.setKey(key);
    }


    /**
     * Executes a non-interactive key-exchange protocol. If encrypt is true,
     * messages will be sent through the encrypted channel. This induces a
     * flush of the stream.
     * <p>
     * After the protocol has been executed, the exchanged key will be used
     * for encryption.
     *
     * @exception IOException if there is a low-level problem.
     * @exception CryptoProtocolException if the protocol could not execute.
     */
    public void reKey(NoninterKeyExClient kex, boolean encrypt)
        throws IOException, CryptoProtocolException
    {
        execute(kex, false);
        try {
            CipherKey key=(CipherKey)kex.sessionKey();
            if(key==null) {
                throw new CryptoProtocolException("A non-interactive protocol should only need one message.");
            }
            emode.setKey(key);
        } catch (ClassCastException e) {
            throw new CryptoProtocolException("The key-exchange protocol proposes to use a non-cipher key for decryption.");
        }
        catch (CryptoException ke) {
            throw new CryptoProtocolException(ke.getMessage());
        }
    }


    /**
     * Executes a non-interactive protocol. If encrypt is true, messages will be
     * sent through the encrypted channel.
     *
     * @exception CryptoProtocolException if there is a problem with the protocol.
     * @exception IOException if there is a problem with the underlying streams.
     */
    public void execute(NoninterProtocolClient prot, boolean encrypt)
        throws IOException, CryptoProtocolException
    {
        OutputStream o = (encrypt ? this : out);
        byte[] msg = prot.message(null);
        if(msg==null) {
            o.write(0);
            o.write(0);
            o.write(0);
            o.write(0);
        } else {
            int l = msg.length;
            o.write(l >>> 24);
            o.write(l >>> 16);
            o.write(l >>>  8);
            o.write(l       );
            o.write(msg);
        }
        o.flush();
        if(!prot.completed()) {
            throw new CryptoProtocolException("The protocol was not completed");
        }
    }


    /** Writes the specified byte to this output stream. */
    public synchronized void write(int b)
        throws IOException
    {
        byte[] buf = { (byte)b };
        write(buf,0,1);
    }


    /**
     * Writes len bytes from the specified byte array starting at offset
     * off to this output stream.
     */
    public synchronized void write(byte[] buf, int off, int len)
        throws IOException
    {
        if(emode==null) {
            throw new IOException("This stream has been closed.");
        }
        byte[] ctext = emode.encrypt(buf,off,len);
        if(ctext.length>0) {
            out.write(ctext,0,ctext.length);
        }
    }


    /**
     * Flushes this output stream and forces any buffered output bytes
     * to be written out to the stream. If the number of bytes written
     * is not a multiple of the plainBlockSize of the CipherKey used
     * for encryption, up to one byte less than a whole block of
     * garbage may be appended to the data when flush is called.
     *
     * <p>It is possible to get rid of the random bytes by calling
     * <code>drain()</code> in the <code>DecryptStream</code> object at
     * the corresponding time.
     *
     * @see org.logi.crypto.io.DecryptStream#drain
     * */
    public synchronized void flush()
        throws IOException
    {
        if(emode==null) {
            throw new IOException("This stream has been closed.");
        }
        try {
            byte[] ctext = emode.flush();
            if(ctext.length>0) {
                out.write(ctext,0,ctext.length);
            }
        } catch (org.logi.crypto.padding.PaddingException pex) {
            throw new IOException( pex.toString() );
        }
        out.flush();
    }


    /**
     * Closes this output stream and releases any system resources
     * associated with this stream.
     *
     * @exception IOException if an I/O error occurs. */
    public void close() throws IOException
    {
        if(emode!=null) {
            try {
                byte[] ctext = emode.flush();
                emode = null;
                out.write(ctext);
                flush();
                out.close();
            } catch (org.logi.crypto.padding.PaddingException pex) {
                throw new IOException( pex.toString() );
            }
        }
    }

}
