// Copyright (C) 2001 Logi Ragnarsson

package org.logi.crypto.padding;

import org.logi.crypto.*;
import org.logi.crypto.keys.*;

import java.util.*;


/**
 * This class implements padding with zero-bytes. This means that the plaintext
 * is padded with zero bytes until it is a whole multiple of plaintext blocks
 * in length. There is no information included which allows proper un-padding
 * so the pad-bytes will be returned along with the actual plaintext data in
 * unPad.
 *
 * @see org.logi.crypto.Crypto#fromString(String)
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class PadZero
    implements Padding
{


    /**
     * Pad the last, perhaps partial, block of plaintext by appending a string
     * of zeroes.
     *
     * @param plaintext The array holding plaintext data to pad.
     * @param off The offset of data within plaintext array.
     * @param len The length of data within plaintext array. This much be less
     *        than a single plaintext block.
     * @param key The key which will be used to encrypt the block.
     *
     * @returns The padded data, whose length will be a multiple of the
     * plaintext block size of the key.
     */
    public byte[] pad(byte[] plaintext, int off, int len, EncryptionKey key)
        throws PaddingException
    {
        int pbs = key.plainBlockSize();
        if( len>pbs ) {
            throw new PaddingException( "Trying to pad more than a single plaintext block." );
        }
        byte[] padded = new byte[ pbs ];
        System.arraycopy(plaintext, off, padded, 0, len );
        return padded;
    }


    /**
     * Pad the last, perhaps partial, block of plaintext.
     *
     * @param padded The array holding padded plaintext data.
     * @param off The offset of data within padded array.
     * @param len The length of data within padded array.
     * @param key The key which will be used to decrypt the block.
     *
     * @returns The unpadded data, possibly zero bytes.
     */
    public byte[] unPad(byte[] padded, int off, int len, DecryptionKey key)
        throws PaddingException
    {
        if(len != key.plainBlockSize() ) {
            throw new PaddingException( "Trying to unpad a block of "+len+" bytes which is different from the plaintext block size of "+key.plainBlockSize()+"." );
        }
        byte[] unpadded = new byte[ len ];
        System.arraycopy( padded, off, unpadded, 0, len );
        return unpadded;
    }


}
