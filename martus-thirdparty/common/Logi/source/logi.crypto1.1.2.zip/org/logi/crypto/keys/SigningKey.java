// Copyright (C) 1998-2000 Logi Ragnarsson

package org.logi.crypto.keys;
import org.logi.crypto.*;
import org.logi.crypto.sign.*;

/**
 * This interface is implemented by keys that can be used to
 * create signatures on fingerprints of data.
 *
 * @author <a href="http://www.logi.org/">Logi Ragnarsson</a> (<a href="mailto:logi@logi.org">logi@logi.org</a>) */
public interface SigningKey
            extends Key
{


    /**
     * Returns the maximum size in bytes of the fingerprints
     * that can be signed. */
    public int signBlockSize();


    /**
     * Returns the length of a signature in bytes. */
    public int signatureSize();


    /**
     * Create a signature for a fingerprint with a private key.
     *
     * @exception KeyException if there are problems, depending on the implementing class.
     */
    public Signature sign(Fingerprint fp)
    throws CryptoException;


}
