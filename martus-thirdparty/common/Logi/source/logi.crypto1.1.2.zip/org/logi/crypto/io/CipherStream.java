// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.io;
import org.logi.crypto.*;
import org.logi.crypto.modes.*;
import org.logi.crypto.keys.*;

import java.io.*;

/**
 * Parent of CipherStreamClient and CipherStreamServer.
 *
 * @see org.logi.crypto.io.CipherStreamServer
 * @see org.logi.crypto.io.CipherStreamClient
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class CipherStream extends Crypto
{

    protected OutputStream out;
    protected InputStream  in;

    protected EncryptStream cOut;
    protected DecryptStream cIn;

    /**
     * Get the encrypted input-stream. */
    public DecryptStream getInputStream()
    {
        return cIn;
    }

    /**
     * Get the key used for encryption. */
    public EncryptionKey getEncryptKey()
    {
        return cOut.getKey();
    }

    /**
     * Re-key the EncryptSession used by this CipherStream. This induces a
     * flush of the outgoing stream.
     *
     * @exception IOException if there is a low-level problem.
     * @exception CryptoException if the internal buffer in the EncryptSession
     * is not empty. */
    public void setEncryptKey(CipherKey key) throws IOException, CryptoException
    {
        cOut.setKey(key);
    }

    /**
     * Get the encrypted output-stream. */
    public EncryptStream getOutputStream()
    {
        return cOut;
    }

    /**
     * Get the key used for decryption. */
    public EncryptionKey getDecryptKey()
    {
        return cOut.getKey();
    }

    /**
     * Re-key the DecryptSession used by this DecryptStream. This causes the
     * incoming stream to be drained.
     *
     * @exception CryptoException if the internal buffer in the DecryptSession
     * is not empty.
     */
    public void setDecryptKey(CipherKey key) throws CryptoException
    {
        cIn.setKey(key);
    }

    /**
     * Closes all streams and releases their resources.
     *
     * @exception IOException if one of the underlying objects refuse to be closed.
     */
    public void close() throws IOException
    {
        if(cIn!=null)
            cIn.close();
        else
            in.close();
        if(cOut!=null)
            cOut.close();
        else
            out.close();
    }

}
