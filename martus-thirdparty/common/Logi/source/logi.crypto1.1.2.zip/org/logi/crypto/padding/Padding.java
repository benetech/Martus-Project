// Copyright (C) 2001 Logi Ragnarsson

package org.logi.crypto.padding;

import org.logi.crypto.keys.*;

import java.util.*;


/**
 * Classes implementing this interface implement a padding scheme such as
 * PKCS#5.
 *
 * @see org.logi.crypto.Crypto#fromString(String)
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public interface Padding
{


    /**
     * Pad the last, perhaps partial, block of plaintext.
     *
     * @param plaintext The array holding plaintext data to pad.
     * @param off The offset of data within plaintext array.
     * @param len The length of data within plaintext array. This much be less
     *        than a single plaintext block.
     * @param key The key which will be used to encrypt the block.
     *
     * @returns The padded data, whose length will be a multiple of the
     * plaintext block size of the key.
     */
    byte[] pad(byte[] plaintext, int off, int len, EncryptionKey key)
        throws PaddingException;


    /**
     * Un-pad the last block of plaintext.
     *
     * @param padded The array holding padded plaintext data.
     * @param off The offset of data within padded array.
     * @param len The length of data within padded array.
     * @param key The key which will be used to decrypt the block.
     *
     * @returns The unpadded data, possibly zero bytes.
     */
    byte[] unPad(byte[] plaintext, int off, int len, DecryptionKey key)
        throws PaddingException;


}
