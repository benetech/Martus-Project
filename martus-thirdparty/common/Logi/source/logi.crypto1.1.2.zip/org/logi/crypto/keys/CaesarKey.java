// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.keys;
import org.logi.crypto.*;

/**
 * The Caesar algorithm is supposedly the one Julius Caesar used by
 * hand many centuries ago. As you can imagine, this is <b>NOT A STRONG
 * CIPHER</b>, but included only to show how to write a very simple
 * Key class for the logi.crypto package. Often, the first assignment given
 * to cryptography students is to break this cipher given no known plaintext.
 * <p>
 * Data is encrypted byte-by-byte by adding a constant value to it and
 * taking the 8 lowest order bits.
 * <p>
 * The CDS for a CaesarKey object is <code>CaesarKey(n)</code> where
 * n is a value in the range 0..255.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public final class CaesarKey extends SymmetricKey implements CipherKey
{

    private byte shift;

    /** Create a new Caesar key with the specified shift. */
    public CaesarKey(byte shift)
    {
        this.shift = shift;
    }

    /** Create a new random Caesar key. */
    public CaesarKey()
    {
        shift = (byte)random.nextInt();
        ;
    }

    /**
     * Used by Crypto.fromString when parsing a CDS.<p>

     * A valid CDS can be created by calling the toString() method.

     * @exception InvalidCDSException if the CDS is malformed.
     * @see org.logi.crypto.Crypto#fromString(String)
     */
    public static CaesarKey parseCDS(String[] param) throws InvalidCDSException
    {
        if(param.length!=1)
            throw new InvalidCDSException("invalid number of parameters in the CDS CaesarKey(key)");
        if(param[0].equals("?"))
            return new CaesarKey();
        byte k = (byte)Integer.parseInt(param[0]);
        return new CaesarKey(k);
    }

    /** The key-size for the Caesar cipher is 1 byte. */
    public int getSize()
    {
        return 1;
    }

    /** The block-size for the Caesar cipher is one byte. */
    public final int plainBlockSize()
    {
        return 1;
    }

    /** The block-size for the Caesar cipher is one byte. */
    public final int cipherBlockSize()
    {
        return 1;
    }

    /** The name of the algorithm is "Caesar". */
    public String getAlgorithm()
    {
        return ("Caesar");
    }

    /** Return true iff the two keys are equivalent. */
    public final boolean equals(Object o)
    {
        if (o==null)
            return false;
        if (o.getClass() != this.getClass())
            return false;
        return shift==((CaesarKey)o).shift;
    }

    /**
     * Return a CDS for this key.
     *
     * @see org.logi.crypto.Crypto#fromString
     */
    public String toString()
    {
        if(shift<0)
            return "CaesarKey("+(256+shift)+")";
        else
            return "CaesarKey("+shift+")";
    }

    /**
     * Encrypt one byte. <code>source[i]</code> is encrypted and put in
     * <code>dest[j]</code>.
     */
    public final void encrypt(byte[] source, int i, byte[] dest, int j)
    {
        dest[j]=(byte)(source[i]+shift);
    }

    /**
     * Decrypt one byte. <code>source[i]</code> is decrypted and put in
     * <code>dest[j]</code>.
     */
    public final void decrypt(byte[] source, int i, byte[] dest, int j)
    {
        dest[j]=(byte)(source[i]-shift);
    }

}
