// Copyright (C) 2001 Logi Ragnarsson

package org.logi.crypto.padding;

import org.logi.crypto.*;
import org.logi.crypto.keys.*;

import java.util.*;


/**
 * This class implements non-padding. If it is asked to add padding to a block
 * of plaintext it will throw an exception, but if the last block is a complete
 * block, then it is simply passed through.
 *
 * @see org.logi.crypto.Crypto#fromString(String)
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class PadNone
    implements Padding
{


    /**
     * Pass whole blocks of plaintext through, but throw exception on partial
     * blocks.
     *
     * @param plaintext The array holding plaintext data to pad.
     * @param off The offset of data within plaintext array.
     * @param len The length of data within plaintext array. This much be less
     *        than a single plaintext block.
     * @param key The key which will be used to encrypt the block.
     *
     * @returns The padded data, whose length will be a multiple of the
     * plaintext block size of the key.
     */
    public byte[] pad(byte[] plaintext, int off, int len, EncryptionKey key)
        throws PaddingException
    {
        int pbs = key.plainBlockSize();
        if( len!=pbs && len!=0 ) {
            throw new PaddingException( "Encrypting less than a whole multiple of plaintext blocks with no padding enabled." );
        }
        byte[] padded = new byte[ len ];
        System.arraycopy(plaintext, off, padded, 0, len );
        return padded;
    }


    /**
     * Pass whole blocks of plaintext through, but throw exception on partial
     * blocks.
     *
     * @param padded The array holding padded plaintext data.
     * @param off The offset of data within padded array.
     * @param len The length of data within padded array.
     * @param key The key which will be used to decrypt the block.
     *
     * @returns The unpadded data, possibly zero bytes.
     */
    public byte[] unPad(byte[] padded, int off, int len, DecryptionKey key)
        throws PaddingException
    {
        if(len != key.plainBlockSize() ) {
            throw new PaddingException( "Trying to unpad a block of "+len+" bytes which is different from the plaintext block size of "+key.plainBlockSize()+"." );
        }
        byte[] unpadded = new byte[ len ];
        System.arraycopy( padded, off, unpadded, 0, len );
        return unpadded;
    }


}
