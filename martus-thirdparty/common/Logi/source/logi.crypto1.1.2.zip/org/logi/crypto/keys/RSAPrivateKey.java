// Copyright (C) 1997-2001 Logi Ragnarsson

package org.logi.crypto.keys;

import org.logi.crypto.*;
import org.logi.crypto.sign.*;
import org.logi.crypto.padding.PadPKCS1v15;

import java.math.BigInteger;

import java.io.IOException;
import java.io.PrintWriter;


/**
 * An instance of this class handles a single RSA private key.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class RSAPrivateKey
            extends K
            implements DecryptionKey, SigningKey, BlindSigningKey, java.security.interfaces.RSAPrivateKey
{


    /** <code>R</code> is the exponent used in all created public keys. */
    protected static final BigInteger E=BigInteger.valueOf(65537);

    /** The private exponent */
    protected BigInteger d;

    /** The RSA key modulus */
    protected BigInteger n;

    /** The factors of the RSA modulus */
    private BigInteger p,q;

    /** The inverse of q, modulo p. */
    private BigInteger u;



    ///////////////////////////////////////////////////////////////////////
    // KEY MANAGEMENT CODE


    /**
     * Create a new RSA key <code>(r,n)</code>.
     */
    public RSAPrivateKey(BigInteger d, BigInteger n)
    {
        super();
        this.d = d;
        this.n = n;
    }


    /**
     * Create a new RSA key <code>(r,n)</code>.
     * It is a private key if <code>pri</code> is true.
     */
    public RSAPrivateKey(BigInteger d, BigInteger p, BigInteger q)
    {
        this(d,p.multiply(q));
        this.p=p;
        this.q=q;
        u = q.modInverse(p);
    }


    /**
     * Used by Crypto.fromString when parsing a CDS.<p>

     * A valid CDS can be created by calling the toString() method.

     * @exception InvalidCDSException if the CDS is malformed.
     * @see org.logi.crypto.Crypto#fromString(String)
     */
    public static RSAPrivateKey parseCDS(String[] param)
    throws InvalidCDSException
    {
        if(param.length!=2 && param.length!=3) {
            throw new InvalidCDSException("invalid number of parameters in the CDS RSAPrivateKey(d,n) or RSAPrivateKey(d,p,q)");
        }

        if( param.length==2 ) {
            // Don't have the factorization
            return new RSAPrivateKey(
                       new BigInteger(param[0],16),
                       new BigInteger(param[1],16)
                   );
        } else {
            return new RSAPrivateKey(
                       new BigInteger(param[0],16),
                       new BigInteger(param[1],16),
                       new BigInteger(param[2],16)
                   );
        }
    }


    /** Returns the largest prime <code>p &lt;= start</code> */
    private static BigInteger findPrime(BigInteger start)
    {
        BigInteger p = start;
        if(!start.testBit(0)) {
            p = p.subtract(ONE);
        }
        while(!p.isProbablePrime(primeCertainty)) {
            p = p.subtract(TWO);
        }

        return p;
    }


    /**
     * Create a pair of public/private keys. The key modulo will be
     * <code>bitLength</code> or <code>bitLength-1</code> bits.
     */
    public static KeyPair createKeys(int bitLength)
    {
        if( bitLength<256 ) {
            bitLength = 256;
        }

        BigInteger p = null;
        BigInteger q = null;
        BigInteger d = null;
        BigInteger n = null;
        while( n==null ) {
            try {
                p = new BigInteger(bitLength/2, primeCertainty, random);
                q = new BigInteger(bitLength/2, primeCertainty, random);
                n = p.multiply(q);
                BigInteger m = p.subtract(ONE).multiply(q.subtract(ONE));
                d = E.modInverse(m);
            } catch (ArithmeticException e) {
                // Key generation failed... just try again.
                n=null;
            }
        }

        return new KeyPair(
                   new RSAPublicKey(E,n),
                   new RSAPrivateKey(d,p,q)
               );
    }


    /**
     * Create a pair of public/private keys from a username/password pair.
     * The public exponent will be 65536 and the private exponent will have
     * <code>bitLength</code> or <code>bitLength-1</code> bits.

     * <p> The keys are created by hashing the password, appending with
     * <code>0</code>'s until it is <code>bitLength</code> bits long and
     * searching for a prime <code>p</code>by counting down from there.
     * Another prime <code>q</code> is found in the same way, but the
     * username is prepended to the password before hashing. Key-generation
     * proceeds as normally from there.

     * <p>The hashFunction parameters directs which hash function to use.
     * It must be the name of a supported hash function, such as MD5 or
     * SHA1.

     * <p> The <code>username</code> does not need to be secret and can in
     * fact be a fixed string. It plays a similar role as SALT in unix
     * password systems in protecting against dictionary attacks.

     * @exception InvalidCDSException if the specified hash function is not available.
     **/
    public static KeyPair createKeys(String username, String password, String hashFunction, int bitLength)
    throws InvalidCDSException
    {
        if (bitLength<256) {
            bitLength=256;
        }

        BigInteger p,q;

        byte[] b = Fingerprint.create(password, hashFunction).getBytes();
        p = new BigInteger(1,b);
        p = p.shiftLeft(bitLength/2-p.bitLength());
        p=findPrime(p);

        b = Fingerprint.create(username+":"+password, hashFunction).getBytes();
        q = new BigInteger(1,b);
        q = q.shiftLeft(bitLength/2-q.bitLength());
        q=findPrime(q);

        BigInteger m=p.subtract(ONE).multiply(q.subtract(ONE));
        BigInteger d=E.modInverse(m);
        BigInteger n=p.multiply(q);

        return new KeyPair(
                   new RSAPublicKey (E,n),
                   new RSAPrivateKey(d,p,q)
               );
    }


    /**
     * Create a KeyPair object holding objects for the public RSA key
     * <code>(e,n)</code> and the private RSA key (d,n).
     *
     * @exception KeyException if (e,n) and (d,n) does not describe a valid
     * pair of RSA keys.
     */
    public static KeyPair createKeys(BigInteger e, BigInteger d, BigInteger n)
    throws KeyException
    {
        Key pub = new RSAPublicKey(e,n);
        Key pri = new RSAPrivateKey(d,n);
        return new KeyPair(pub,pri);
    }


    /** Return the size of the key modulo in bits. */
    public int getSize()
    {
        return n.bitLength();
    }


    /** The name of the algorithm is "RSA". */
    public String getAlgorithm()
    {
        return ("RSA");
    }


    /** Return public modulus. */
    public BigInteger getModulus()
    {
        return n;
    }


    /** Return private exponent. */
    public BigInteger getPrivateExponent()
    {
        return d;
    }


    /**
     * Calculate the fingerprint for this key or the other in the
     * pair.
     */
    protected Fingerprint calcFingerprint(boolean other, String algorithm) throws InvalidCDSException
    {
        // The key-pair is uniquely defined by n, since it factors uniquely
        // into p and q which are used to calculate both exponents.
        HashState fs=HashState.create(algorithm);
        fs.update(n.toByteArray());
        if(other) {
            fs.update("pub");
        } else {
            fs.update("pri");
        }
        return fs.calculate();
    }


    /**
     * Return a CDS for this key.
     *
     * @see org.logi.crypto.Crypto#fromString
     */
    public String toString()
    {
        if( p==null ) {
            // Don't know the factors of n
            return "RSAPrivateKey("+d.toString(16)+','+n.toString(16)+')';
        } else {
            return "RSAPrivateKey("+d.toString(16)+','+p.toString(16)+','+q.toString(16)+')';
        }
    }


    /**
     * Print this object to out, indented with ind tabs, going down at most
     * rec levels of recursion. */
    public void prettyPrint(PrintWriter out, int ind, int rec)
    throws IOException
    {
        if(rec<0) {
            return;
        }

        for(int i=0; i<ind; i++) {
            out.print('\t');
        }
        out.println("RSAPrivateKey(");

        for(int i=0; i<=ind; i++) {
            out.print('\t');
        }
        out.print(d.toString(16));
        out.println(",");

        if( p==null ) {
            // We don't know the factorization of n.
            for(int i=0; i<=ind; i++) {
                out.print('\t');
            }
            out.println(n.toString(16));
        } else {
            // We know the factorization of n.
            for(int i=0; i<=ind; i++) {
                out.print('\t');
            }
            out.print(p.toString(16));
            out.println(",");

            for(int i=0; i<=ind; i++) {
                out.print('\t');
            }
            out.println(q.toString(16));
        }

        for(int i=0; i<ind; i++) {
            out.print('\t');
        }
        out.print(")");
    }


    /** Return true iff the two keys are equivalent. */
    public boolean equals(Object o)
    {
        if (o==null) {
            return false;
        }
        if((o instanceof RSAPrivateKey)) {
            RSAPrivateKey other = (RSAPrivateKey)o;
            return (this.d.equals(other.d) && this.n.equals(other.n));
        } else {
            return false;
        }
    }


    /**
     * Check if a key mathces this. This is true if this and key are a matched
     * pair of public/private keys. */
    public final boolean matches(Key key)
    {
        if ( !(key instanceof RSAPublicKey) ) {
            return false;
        }
        RSAPublicKey k=(RSAPublicKey)key;
        return n.equals(k.n);
    }


    /**
     * Perform the RSA decryption transformation.
     */
    private BigInteger privateTransformation(BigInteger y)
    {
        if(p==null) {
            // Can't use chineese remainder theorem.
            return y.modPow(d,n);
        } else {
            BigInteger a = y.modPow(d,p);
            BigInteger b = y.modPow(d,q);
            return a.subtract(b).multiply(u).mod(p).multiply(q).add(b);
        }
    }



    ///////////////////////////////////////////////////////////////////////
    // CIPHER CODE

    /**
     * Returns the size of the blocks that can be encrypted in one call
     * to encrypt(). For RSA keys this depends on the size of the key.
     */
    public int plainBlockSize()
    {
        return (n.bitLength()-1)/8;
    }


    /**
     * Returns the size of the blocks that can be decrypted in one call
     * to decrypt(). For RSA keys this depends on the size of the key.
     */
    public int cipherBlockSize()
    {
        return plainBlockSize()+1;
    }


    /**
     * Decrypt one block of data. The ciphertext is taken from
     * <code>source</code> starting at offset <code>i</code> and
     * plaintext is written to <code>dest</code>, starting at
     * offset <code>j</code>.
     * <p>
     * The amount of data read and written will match the values returned
     * by <code>cipherBlockSize()</code> and <code>plainBlockSize()</code>.
     */
    public void decrypt(byte[] source, int i, byte[] dest, int j)
    {
        int plainSize = plainBlockSize();
        byte[] cipher;

        if( i==0 && source.length==plainSize+1 ) {
            cipher = source;
        } else {
            cipher = new byte[plainSize+1];
            System.arraycopy( source,i, cipher,0, plainSize+1 );
        }

        byte[]plain = privateTransformation(new BigInteger(1,cipher)).toByteArray();

        if( plain.length >= plainSize ) {
            // The output is a full plain block
            System.arraycopy( plain,plain.length-plainSize, dest, j, plainSize );
        } else {
            // The output is a bit on the short side
            System.arraycopy( plain,0, dest,j+plainSize-plain.length, plain.length );
        }
        for ( int k=plainSize-plain.length-1; k>=0; k-- ) {
            dest[j+k]=0;
        }
    }


    ///////////////////////////////////////////////////////////////////////
    // SIGNATURE CODE

    /**
     * Returns the maximum size in bytes of the fingerprint
     * that can be signed. */
    public int signBlockSize()
    {
        // plain block - bytes used for algorithm ID, DER encoding and mninimum padding.
        return plainBlockSize()-29;
    }


    /**
     * Returns the length of the signature in bytes. */
    public int signatureSize()
    {
        return cipherBlockSize();
    }


    /**
     * Create a signature for a Fingerprint with a private key.
     *
     * If fp is a BlindFingerprint, then a BlindSignature will be returned,
     * so in this case the return value can be safely typecast to
     * BlindSignature.
     *
     * @exception KeyException if the key modulus is shorter than the signature.
     * @exception KeyException if this is not a private key
     */
    public Signature sign(Fingerprint fp)
        throws CryptoException
    {
        if(fp instanceof BlindFingerprint) {
            return sign((BlindFingerprint)fp);
        }

        BigInteger plain = new BigInteger(1, PadPKCS1v15.EMSA_PKCS1_v1_5(fp, plainBlockSize()) );
        BigInteger signature = privateTransformation(plain);

        return new Signature(
                   fp.getHashFunc(),
                   trimLeadingZeroes(signature.toByteArray())
               );
    }



    ///////////////////////////////////////////////////////////////////////
    // BLIND SIGNATURE CODE


    /**
     * Create a signature for a blinded fingerprint with a private key.

     * @exception KeyException if there are problems, depending on the implementing class.
     */
    public BlindSignature sign(BlindFingerprint fp)
        throws CryptoException
    {
        BigInteger signature = privateTransformation(new BigInteger(1,fp.getBytes()));
        return new BlindSignature(
                   fp.getHashFunc(),
                   fp.getBlindFunc(),
                   trimLeadingZeroes(signature.toByteArray())
               );
    }


}
