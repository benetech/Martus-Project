// Copyright (C) 1998-2001 Logi Ragnarsson

package org.logi.crypto.demo;

import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.modes.*;
import org.logi.crypto.protocols.*;
import org.logi.crypto.io.*;

import java.util.Random;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 * This application launches multiple client threads connecting to a server
 * thread, using key-exchange and encryption in OFB mode.

 * <p> This makes use of the EncryptStream DecryptStream, EncryptOFB,
 * DecryptOFB, TriDES, EncryptedKeyExClient, EncryptedKeyExServer,
 * DHKeyExClient, DHKeyExServer, DHEKEKeyExClient and DHEKEKeyExClient
 * classes.

 * <p> 10 client threads are created which each repeatedly connects to the
 * main server thread. The main server thread spawns a sub-thread for each
 * connection. Each client thread negotiates a TriDES session key with its
 * corresponding server thread either the Diffie-Hellman protocol, the
 * Diffie-Hellman EKE protocol or by recieving an encrypted key from the
 * server. The client then uses this key in OFB mode to send a number to
 * the server thread and recieve the square of the number. The result is
 * then printed to the screen. Ocasionally a new key will be negotiated and
 * the mode classes rekeyed.

 * <p> Since each EncryptOFB and DecryptOFB object launches a thread to
 * pre-calculate an xor-stream, more than 60 threads are created to perform
 * the calculations.

 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a> (<a
 * href="mailto:logir@logi.org">logir@logi.org</a>)

 * @see org.logi.crypto.modes.EncryptMode
 * @see org.logi.crypto.keys.CipherKey
 * @see org.logi.crypto.protocols.InterKeyExClient

 */
public class ClientServer extends Crypto
{

    private ClientServer()
    {}

    static int serverPort;
    static Random rand = new Random();

    // Used for DH-EKE, SendHash and QRAuth protocols
    static CipherKey secret;

    // Used for EncryptedKeyExchange protocol
    static KeyPair serverKeys;
    static KeyPair clientKeys;

    // Should we perform separate authentication?
    static boolean auth;

    // The key-exchange protocol to use. Is one of DH, EncryptedKey, SendHash
    static String keyEx;

    static class ClientThread extends Thread
    {
        int id;

        public ClientThread(int id)
        {
            this.id = id;
        }

        public InterKeyExClient makeKexCli() throws Exception
        {
            if(keyEx.equals("DH"))
                return new DHKeyExClient(512,"TriDESKey");
            if(keyEx.equals("EncryptedKey"))
                return new EncryptedKeyExClient((EncryptionKey)serverKeys.getPublic(),
                                                (SigningKey)clientKeys.getPrivate(),
                                                new TriDESKey());
            if(keyEx.equals("SendHash"))
                return new SendHashKeyExClient(secret);
            if(keyEx.equals("DHEKE"))
                return new DHEKEKeyExClient(512,"TriDESKey",secret);
            return null;
        }

        public void run()
        {
            while(true) {
                Socket s=null;
                CipherStreamClient csc=null;
                try {
                    System.err.println("C("+id+")\tCreating CipherStreamClient");
                    s = new Socket("127.0.0.1",serverPort);
                    csc = new CipherStreamClient(s.getInputStream(),
                                                 s.getOutputStream(),
                                                 makeKexCli(),
                                                 new EncryptOFB(64),
                                                 new DecryptOFB(64)
                                                );
                    if(auth) {
                        System.err.println("S\tAuthenticating");
                        csc.execute(new QRAuthClient(secret),true);
                    }
                    DataInputStream  in  = new DataInputStream (csc.getInputStream() );
                    DataOutputStream out = new DataOutputStream(csc.getOutputStream());
                    do {
                        int n = rand.nextInt() % 20 + 19;
                        out.writeInt(n);
                        int n2=in.readInt();
                        System.err.println("C("+id+")\t"+n+"^2="+n2);
                        if(n==0) {
                            System.err.println("C("+id+")\trekeying...");
                            csc.reKey(makeKexCli(), false);
                            System.err.println("C("+id+")\trekeyed...");
                        }
                    } while (rand.nextInt() % 50 != 0);
                    try {
                        // Probably the socket is already closed, but try just in case.
                        csc.close();
                    } catch (SocketException se) {
                        // swallow exception
                    }
                } catch (Exception e) {
                    System.err.println("C("+id+")\tDied with an exception");
                    e.printStackTrace(System.err);
                    try {
                        if (csc!=null)
                            csc.close();
                    } catch (Exception e2) {
                        ;
                    }
                }
            }
        }

    }

    static class ServerThread extends Thread
    {
        Socket s;

        public ServerThread(Socket s)
        {
            this.s = s;
        }

        public InterKeyExServer makeKexSer ()
        {
            if(keyEx.equals("DH"))
                return new DHKeyExServer(512,"TriDESKey");
            if(keyEx.equals("EncryptedKey"))
                return new EncryptedKeyExServer((DecryptionKey)serverKeys.getPrivate(),
                                                (VerificationKey)clientKeys.getPublic());
            if(keyEx.equals("SendHash"))
                return new SendHashKeyExServer();
            if(keyEx.equals("DHEKE"))
                return new DHEKEKeyExServer(512,"TriDESKey",secret);
            return null;
        }

        public void run()
        {
            CipherStreamServer css = null;
            try {
                System.err.println("S\tCreating CipherStreamServer");
                css = new CipherStreamServer(s.getInputStream(),
                                             s.getOutputStream(),
                                             makeKexSer(),
                                             new EncryptOFB(64),
                                             new DecryptOFB(64)
                                            );
                if(auth) {
                    System.err.println("S\tAuthenticating");
                    css.execute(new QRAuthServer(secret),true);
                }
                DataInputStream  in  = new DataInputStream (css.getInputStream() );
                DataOutputStream out = new DataOutputStream(css.getOutputStream());
                while(true) {
                    int n = in.readInt();
                    out.writeInt(n*n);
                    if(n==0) {
                        System.err.println("S\trekeying...");
                        css.reKey(makeKexSer(), false);
                        System.err.println("S\trekeyed...");
                    }
                }
            } catch (Exception e) {
                if(!(e instanceof java.io.EOFException)) {
                    System.err.println("S\tDied with an exception");
                    e.printStackTrace();
                }
                try {
                    if(css!=null)
                        css.close();
                } catch (Exception e2) {}
                ;
            }
            System.err.println("S\tclosing connection");
        }
    }

    private static void help()
    {
        System.err.println("Use: java org.logi.crypto.test.TestCliSer <key-ex> [auth]");
        System.err.println("where <key-ex> is one of DH, EncryptedKey or SendHash.");
        System.err.println();
        System.err.println("DH             Diffie-Hellman. Encryption but no authentication.");
        System.err.println("DHEKE          DH-EKE key-exchange and authentication. Encryption and authentication.");
        System.err.println("EncryptedKey   Encrypted key sent. Encryption and implicit authentication.");
        System.err.println("SendHash       Send hash of key to use. Encryption and implicit authentication.");
        System.err.println("");
        System.err.println("auth           Use the query-responce protocol for authentication.");
    }

    public static void main(String[] arg)
    {
        Crypto.initRandom();

        if(arg.length<1) {
            help();
            return;
        }
        keyEx = arg[0];
        if(!keyEx.equals("DH") &&
                !keyEx.equals("DHEKE") &&
                !keyEx.equals("EncryptedKey") &&
                !keyEx.equals("SendHash")) {
            help();
            return;
        }

        if(arg.length>1) {
            if(arg[1].equals("auth"))
                auth=true;
            else {
                help();
                return;
            }
        }

        // Create secret key and put it in the default key-ring
        secret=new DESKey();
        KeyRing kr  = new KeyRing();
        kr.insert(secret);
        Crypto.keySource = kr;

        // If we are using encrypted key exchange,
        // then we'll need two key-pairs.
        if(keyEx.equals("EncryptedKey")) {
            clientKeys = RSAPrivateKey.createKeys(256);
            serverKeys = RSAPrivateKey.createKeys(256);
        }

        // Create server socket on random port (and save the port number)
        ServerSocket ss;
        Crypto.random = new Random();
        do {
            try {
                serverPort = rand.nextInt() % 32768 + 32768;
                System.out.println("Server on port "+serverPort);
                ss = new ServerSocket(serverPort);
            } catch (Throwable e) {
                System.err.println("Failed to open server port "+serverPort);
                ss = null;
            }
        } while(ss==null);

        // Crate 10 client threads
        for (int id=0; id<10; id++)
            new ClientThread(id).start();

        // Loop to wait for connections and create a thread for each
        while(true) {
            try {
                System.err.println("S\twaiting for connection");
                new ServerThread(ss.accept()).start();
            } catch (IOException e) {
                System.err.println("S\tConnection threw an exception");
            }
        }
    }

}
