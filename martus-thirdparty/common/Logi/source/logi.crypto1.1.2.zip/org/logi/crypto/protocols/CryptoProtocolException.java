// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.protocols;
import org.logi.crypto.*;

/**
 * This exception is thrown when a problem arises in a cryptographic
 * protocol, such as an invalid message being received.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a> (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class CryptoProtocolException extends CryptoException
{

    /** Create a new CryptoProtocolException with no message. */
    public CryptoProtocolException()
    {}

    /** Create a new CryptoProtocolException with the message msg. */
    public CryptoProtocolException(String msg)
    {
        super(msg);
    }

}
