// Copyright (C) 1998,2000 Logi Ragnarsson

package org.logi.crypto.protocols;

/**
 * This interface is implemented by classes for the client portion of an
 * interactive protocol.
 * <p>
 * In this context, the party which initiates the protocol is considered the
 * client. Interactive means that the client may need to recieve information
 * from the server, so the protocol can be used off-line.
 *
 * @see org.logi.crypto.protocols.InterProtocolServer
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public interface InterProtocolClient
{

    /** Returns true iff this end of the protocol is completed. */
    public boolean completed();

    /**
     * Get the next message in the protocol.
     * <p>
     * <code>received</code> is the last message received form the server
     * and has not yet been sent to the client.
     * <p>
     * The returned value is the next message to send to the server or null
     * if no more messages need to be sent and the protocol is terminated.
     *
     * @exception CryptoProtocolException if a problem arises with the protocol.
     */
    public byte[] message(byte[] received) throws CryptoProtocolException;

    /**
     * Returns the maximum expected size of a message for this protocol. */
    public int maxMessageSize();

}
