// Copyright (C) 1998-2000 Logi Ragnarsson

package org.logi.crypto.test;
import org.logi.crypto.*;
import org.logi.crypto.random.*;

import java.util.Random;
import java.security.SecureRandom;
import java.io.*;
import java.text.*;

/**
 * This application tests the various random number generation classes.
 *
 * @see org.logi.crypto.keys.Key
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class TestRandom extends Crypto
{

    private TestRandom()
    {}

    private static void printTime(long t)
    {
        System.out.println("Time: " + (t/1000) + "." + (t%1000) + " s");
    }

    private static class MaurersTest
    {

        // These values may exceed 2^31, so we need long!

        long need;  // Total number of blocks needed.
        long N;     // Blocks handled so far
        long Q;     // Number of blocks to initialize
        int L;     // Block-size in bits

        long[] T;   // LZ memory
        double r;  // Sum of logs of probabilities.

        int mask;  // bit-mask to extract block
        int buf;   // Bits left over from last byte array
        int bufL;  // Number of bits in buf

        public MaurersTest(int L)
        {
            int J = 1<<L;

            need = 10110*J*L;
            N=0;
            Q=10*J;
            this.L=L;

            T=new long[J+1];
            r=0;

            mask = J-1;
            bufL=0;
        }

        public void feed(byte[] bits)
        {
            int n=bits.length;

            int byteOff = 0;
            int bitOff = 0;

            int b = buf;
            int l=L-bufL;
            while(l>0) {
                if(l<8-bitOff) {
                    b = (b<<l) | ((bits[byteOff]&0xff) >> (8-l-bitOff));
                    bitOff+=l;
                    l=0;
                } else {
                    b = (b<<(8-bitOff)) | (bits[byteOff]&0xff);
                    l-=(8-bitOff);
                    bitOff=0;
                    byteOff++;
                }
            }
            b&=mask;

            // b contains a bock assembled from the bufL bits in buf and
            // however many bits are needed from bits to complete it.

            while(true) {
                // b contains a block to process

                if(N<Q) {
                    // Use b to initialize T
                    T[b]=N;
                } else {
                    // Use b for actual statistics
                    r += Math.log(N-T[b]);
                    T[b]=N;
                }
                N++;

                if(8*(n-byteOff)-bitOff<L) {
                    // not a full block left
                    break;
                }

                l=L;
                while(l>0) {
                    if(l<8-bitOff) {
                        b = (b<<l) | ((bits[byteOff]&0xff) >> (8-l-bitOff));
                        bitOff+=l;
                        l=0;
                    } else {
                        b = (b<<(8-bitOff)) | (bits[byteOff]&0xff);
                        l-=(8-bitOff);
                        bitOff=0;
                        byteOff++;
                    }
                }
                b&=mask;

            }

            // All full blocks have been processed.

            bufL = 8*(n-byteOff)-bitOff;

            b=0;
            l=bufL;
            while(l>0) {
                if(l<8-bitOff) {
                    b = (b<<l) | ((bits[byteOff]&0xff) >> (8-l-bitOff));
                    bitOff+=l;
                    l=0;
                } else {
                    b = (b<<(8-bitOff)) | (bits[byteOff]&0xff);
                    l-=(8-bitOff);
                    bitOff=0;
                    byteOff++;
                }
            }
            buf = b;

            // buf may contain some left-overs for the next feed
        }

        public boolean done()
        {
            return N>=need;
        }

        public long eaten()
        {
            if(N<=Q)
                return 0;
            return N-Q;
        }

        public double result()
        {
            return r/(N-Q)/Math.log(2);
        }

    }

    private static int minL=4;
    private static int maxL=10;
    private static long randBuf;

    // See The Handbook og Applied Cryptography, section 5.4.5
    private static double[] mu = {
                                     0.7326495,  1.5374383,  2.4016068,  3.3112247,
                                     4.2534266,  5.2177052,  6.1962507,  7.1836656,
                                     8.1764218,  9.1723243,  10.170032,  11.168765,
                                     12.168070,  13.167693,  14.167488,  15.167379
                                 };

    private static double[] sigma2 = {
                                         0.690, 1.338, 1.901, 2.358,
                                         2.705, 2.954, 3.125, 3.238,
                                         3.311, 3.356, 3.384, 3.401,
                                         3.410, 3.416, 3.419, 3.421
                                     };

    // The 1% fractile
    private static double limitFractile=2.3263;

    private static boolean test(Random r) throws Exception
    {
        boolean ok = true;

        byte[] bits = new byte[(int)((randBuf+999)/1000)];
        System.out.println("Generating "+TestIterate.metricString(randBuf,1024)+"B");

        DecimalFormat decA = new DecimalFormat("0.000000000 ");
        DecimalFormat decP = new DecimalFormat("0.0");

        MaurersTest[] mt = new MaurersTest[maxL-minL+1];

        System.out.print("L:\t ");
        for(int L=minL; L<=maxL; L++) {
            mt[L-minL] = new MaurersTest(L);
            System.out.print(L);
            if(L<10)
                System.out.print(' ');
            System.out.print("           ");
        }
        System.out.println();

        System.out.print("0%");
        for(int i=0; i<1000; i++) {
            r.nextBytes(bits);
            System.out.print('\r');
            if(i==999)
                System.out.print("X_u  \t");
            else
                System.out.print(decP.format(0.1*i+0.1)+"%\t");

            for(int L=minL; L<=maxL; L++) {
                mt[L-minL].feed(bits);
                double Xu = mt[L-minL].result();
                if(Xu<10)
                    System.out.print(' ');
                System.out.print(decA.format(Xu));
            }
        }
        System.out.println();

        boolean[] pass = new boolean[maxL-minL+1];

        System.out.print("dev.\t");
        for(int L=minL; L<=maxL; L++) {
            double Xu = mt[L-minL].result();
            double s2 = sigma2[L-minL]/mt[L-minL].eaten();
            double dev = (Math.abs(Xu-mu[L-1])/Math.sqrt(s2));  // How many std.dev from norm
            if(dev<10)
                System.out.print(' ');
            System.out.print(decA.format(dev));
            pass[L-minL] = (dev<limitFractile);
            ok &= pass[L-minL];
        }
        System.out.println();

        System.out.print("passed\t ");
        for(int L=minL; L<=maxL; L++) {
            if(pass[L-minL]) {
                System.out.print("yes          ");
            } else {
                System.out.print("NO!          ");
            }
        }
        System.out.println();

        return ok;
    }


    public static void help(Object msg)
    {
        if(msg!=null) {
            System.out.println(msg);
            System.out.println();
        }
        System.out.println("use: java org.logi.crypto.test.TestRandom [-l n]");
        System.out.println();
        System.out.println("Applies Maurer's test to the random number generators.");
        System.out.println();
        System.out.println("-l sets the block size and should be chosen between 6 and 16,");
        System.out.println(" high for horough testing, low for reasonable running times.");
        System.out.println();
        System.out.println("Note that passing this test does not mean that the generator");
        System.out.println("is good, merely that it doesn't have particular bad statistical");
        System.out.println("properties. In particular, the java.util.Random class passes");
        System.out.println("the test but is *not* useful for cryptographic purposes.");
        System.out.println();
        System.out.println("Similarly, the PureSpinner does *not* pass the test and is in");
        System.out.println("fact not a good generator on its own. However, it collects");
        System.out.println("entropy from the environment, so it can increase the");
        System.out.println("unpredictability of e.g. RandomMD5.");
        System.out.println();
        System.out.println("Finally, even God's Own Dice will sometimes fail the test.");
        System.out.println("Perversely, since a random bit generator is equally likely to");
        System.out.println("generate *any* sequence at all by definition, it is quite");
        System.out.println("capable of generating a sequence which will fail the test.");
        System.out.println("However, this is *very* unlikely. If you see it twice I want");
        System.out.println("to know.");
        System.out.println();
        System.out.println("The usefullness of this program is left as an excercise for");
        System.out.println("the reader.");
        System.exit(1);
    }

    public static void main(String[] arg)
    {
        Crypto.initRandom();

        boolean force=false;

        for(int i=0; i<arg.length; i++) {
            if(arg[i].equals("-h")) {
                help(null);
            } else if(arg[i].equals("-f")) {
                force=true;
            } else {
                if(i+1 == arg.length)
                    help("Invalid parameters");
                if(arg[i].equals("-l")) {
                    try {
                        maxL = Integer.parseInt(arg[i+1]);
                    } catch (Exception e) {
                        help(e);
                    }
                } else {
                    help("Invalid parameters");
                }
                i++;
            }
        }

        if(!force && maxL<6)
            help("You must give a -l parameter of at least 6.");
        if(maxL>16)
            help("The maximum block-length is 16 bits.");

        randBuf = maxL*10110*(1<<maxL);
        try {
            System.out.println();
            System.out.print("Initializing java.util.Random\t");
            long start = System.currentTimeMillis();
            Random r = new Random();
            long end = System.currentTimeMillis();
            printTime(end-start);
            test(r);
        } catch (Throwable e) {
            e.printStackTrace();
        }

        try {
            System.out.println();
            System.out.print("Initializing org.logi.crypto.random.RandomMD5 (no re-seeding)\t");
            long start = System.currentTimeMillis();
            Random r = new RandomMD5(new PureSpinner(),256,0);
            int i = r.nextInt();
            long end = System.currentTimeMillis();
            printTime(end-start);
            if(!test(r)) {
                System.out.println("The sequence failed one or more tests. This *will* happen occasionally,");
                System.out.println("even with a perfect random bit generator, but very infrequently.");
                System.out.println("If you see it twice you should probably contact the developer");
                System.out.println("of the library.");
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }

        /*
        try{
        System.out.println();
            System.out.print("Initializing reading of /dev/zero\t");
        long start = System.currentTimeMillis();
            Random r = new RandomFromStream(new FileInputStream("/dev/zero"));
            long end = System.currentTimeMillis();
            printTime(end-start);
        test(r);
    } catch (Throwable e){
            e.printStackTrace();
    }
        */

        try {
            System.out.println();
            System.out.print("Initializing reading of /dev/urandom\t");
            long start = System.currentTimeMillis();
            Random r = new RandomFromStream(new FileInputStream("/dev/urandom"));
            long end = System.currentTimeMillis();
            printTime(end-start);
            test(r);
        } catch (Throwable e) {
            e.printStackTrace();
        }

        try {
            System.out.println();
            System.out.print("Initializing java.security.SecureRandom\t");
            long start = System.currentTimeMillis();
            Random r = new SecureRandom();
            long end = System.currentTimeMillis();
            printTime(end-start);
            test(r);
        } catch (Throwable e) {
            e.printStackTrace();
        }

        try {
            System.out.println();
            System.out.print("Initializing org.logi.crypto.random.PureSpinner\t");
            long start = System.currentTimeMillis();
            Random r = new PureSpinner();
            long end = System.currentTimeMillis();
            printTime(end-start);
            System.out.println("(this is not a statistically good RNG but");
            System.out.println(" collects entropy for use in e.g. RandomMD5)");
            test(r);
        } catch (Throwable e) {
            e.printStackTrace();
        }

    }

}
