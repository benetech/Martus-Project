// Copyright (C) 1998-2001 Logi Ragnarsson

package org.logi.crypto.modes;

import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.padding.*;

/**
 * Cipher Block Chaining mode xors each plain block with the previous
 * cipher block before encrypting. See FIPS PUB 81 or ANSI X3.106 or
 * ISO IS8372 for a complete specification.
 * <p>
 * A padding engine can be passed to the constructor of the EncryptCBC object
 * to allow the encryption of data which is not a whole multiple of plaintext
 * blocks. If no padding engine is given, then the padding used depends on the
 * key class being used.
 * <p>
 * If the key implements the CipherKey interface, which makes it a key for a
 * symmetric cipher, then PKCS#5 padding is used. Otherwise PKCS#1 padding is
 * used, which is appropriate for RSA and Diffie-Hellman/El-Gamal.
 *
 * @see org.logi.crypto.modes.DecryptCBC
 *
 * @author <a href="http://www.logi.org/">Logi Ragnarsson</a>
 *        (<a href="mailto:logi@logi.org">logi@logi.org</a>) */
public class EncryptCBC
    extends EncryptMode
{


    /** The key to use for encryption. */
    private EncryptionKey key;

    /** The padding engine to use on the last block. */
    private Padding padding;

    /**
     * <code>buffer[0..bufPos-1]</code> is data waiting to be part of a
     * full block. */
    private byte[] buffer;
    private int bufPos;

    /** Input block size and output block size. */
    private int pbs;
    private int cbs;

    /**
     * The last cipher block if any, otherwise <code>null</code>. */
    private byte[] last;


    /**
     * Create a new CBC-mode encrypt session with the specified key.
     *
     * @param key The key to use for encryption.
     * @param padding The padding engine to use.
     */
    public EncryptCBC(EncryptionKey key, Padding padding)
    {
        this.padding = padding;
        try {
            setKey(key);
        } catch (CryptoException e) {
            // Not thrown on first call.
        }
    }


    /**
     * Create a new CBC-mode encrypt session with the specified key and PKCS#5
     * padding.
     *
     * @param key The key to use for encryption.
     */
    public EncryptCBC(EncryptionKey key)
    {
        try {
            setKey(key);
        } catch (CryptoException e) {
            // Not thrown on first call.
        }
    }


    /**
     * Create a new CBC-mode encrypt session with no key. No
     * encryption can be performed until the <code>setKey()</code>
     * method has been called.
     *
     * @param padding The padding engine to use.
     */
    public EncryptCBC(Padding padding)
    {
        this.padding = padding;
    }


    /**
     * Create a new CBC-mode encrypt session with no key and PKCS#5 padding. No
     * encryption can be performed until the <code>setKey()</code>
     * method has been called.
     *
     * @param padding The padding engine to use.
     */
    public EncryptCBC()
    {
        this.padding = null;
    }


    /** Return the key used for encryption. */
    public EncryptionKey getKey()
    {
        return key;
    }


    /**
     * Return the size of the blocks of plaintext encrypted by this object.
     */
    public int plainBlockSize()
    {
        return 1;
    }


    /** Set the key to use for encryption. Do not call this method
     * when there may be data in the internal buffer.
     *
     * @exception CryptoException if there is data in the internal buffer
     * which should be encrypted with the old key. */
    public synchronized void setKey(EncryptionKey key)
        throws CryptoException
    {
        if( bufPos!=0 ) {
            throw new CryptoException("Internal buffer not empty.");
        }
        this.key = key;
        pbs = key.plainBlockSize();
        cbs = key.cipherBlockSize();
        buffer = new byte[key.plainBlockSize()];
        if( padding==null ) {
            // We have defered choosing padding until we knew the key type
            if( key instanceof CipherKey ) {
                this.padding = new PadPKCS5();
            } else {
                this.padding = new PadPKCS1v15();
            }
        }
    }


    /**
     * Send bytes to the EncryptCBC object for encryption.
     * <p>
     * Encrypt <code>length</code> bytes from <code>source</code>,
     * starting at <code>i</code> and return the ciphertext. Data is
     * encrypted in blocks, so only whole blocks of ciphertext
     * are written to <code>dest</code>. Any remaining plaintext will be
     * stored and prepended to <code>source</code> in the next call to
     * <code>encrypt</code>.
     */
    public synchronized byte[] encrypt( byte[] source, int i, int length )
    {
        int blocks = (bufPos+length)/pbs;
        byte[] dest;
        int j=0;    // dest[0..j-1] is ciphertext

        // Create and write IV
        if( last==null ) {
            dest = new byte[blocks*cbs+pbs];
            for(int k=0; k<pbs; k++) {
                dest[k] = (byte)random.nextInt();
            }
            last = new byte[pbs];
            System.arraycopy( dest,0, last,0, pbs );
            j=pbs;
        } else {
            dest = new byte[blocks*cbs];
        }

        // Use saved data
        if( bufPos>0 ) {
            // We have unencrypted data in the buffer
            int n=Math.min(length, buffer.length-bufPos);
            System.arraycopy(source,i, buffer,bufPos, n);
            bufPos+=n;
            i+=n;
            length-=n;
            blocks--;
            if( bufPos==buffer.length ) {
                // We've filled the buffer
                for( int k=0; k<pbs; k++ ) {
                    buffer[k]^=last[k];
                }
                key.encrypt( buffer,0, dest,0 );
                System.arraycopy( dest,0, last,0, pbs );
                j += cbs;
                bufPos=0;
            } else {
                return dest;  // can't even fill one block...
            }
        }
        int ii=i;

        // Encrypt first block
        if( blocks>0 ) {
            for( int k=0; k<pbs; k++ ) {
                buffer[k] = (byte)(source[i+k]^last[k]);
            }
            key.encrypt( buffer, 0, dest, j );
            i+=pbs;
            j+=cbs;

            // Encrypt entire blocks
            for ( int b=1; b<blocks; b++ ) {
                for( int k=0; k<pbs; k++ ) {
                    // We know the last cipher block is still in dest!
                    buffer[k] = (byte)(source[i+k]^dest[j+k-cbs]);
                }
                key.encrypt( buffer, 0, dest, j );
                i+=pbs;
                j+=cbs;
            }
            System.arraycopy( dest,j-cbs,last,0,pbs ); // Save last block.
        }

        // Save possible incomplete block


        bufPos = length-(i-ii);
        if( bufPos!=0 ) {
            System.arraycopy( source,i, buffer,0, bufPos );
        }

        return dest;
    }


    /**
     * Pads the internal buffer acording to PKCS#5 (See RFC 1423, sec 1.1),
    * encrypts it and returns the ciphertext.  */
    public synchronized byte[] flush()
        throws PaddingException
    {
        byte[] padded = padding.pad( buffer, 0, bufPos, key );
        if( padded.length==0 ) {
            return padded;
        }
        if( padded.length!=pbs ) {
            throw new PaddingException( "Padding engine returned "+padded.length+" bytes, but the plain block size is "+pbs );
        }
        for( int i=0; i<pbs; i++ ) {  // CBC-chaining
            padded[ i ] ^= last[ i ];
        }

        byte[] dest = new byte[ cbs ];
        key.encrypt( padded,0, dest,0 );
        return dest;
    }


}
