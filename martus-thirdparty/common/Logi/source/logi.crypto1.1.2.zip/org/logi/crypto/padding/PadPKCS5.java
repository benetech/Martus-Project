// Copyright (C) 2001 Logi Ragnarsson

package org.logi.crypto.padding;

import org.logi.crypto.*;
import org.logi.crypto.keys.*;

import java.util.*;


/**
 * This class implements PKCS#5 padding. See RFC 1423, section 1.1.
 *
 * @author <a href="http://www.logi.org/">Logi Ragnarsson</a>
 * (<a href="mailto:logi@logi.org">logi@logi.org</a>)
 */
public class PadPKCS5
    implements Padding
{

    /**
     * Pad the last, perhaps partial, block of plaintext.
     *
     * @param plaintext The array holding plaintext data to pad.
     * @param off The offset of data within plaintext array.
     * @param len The length of data within plaintext array. This much be less
     *        than a single plaintext block.
     * @param key The key which will be used to encrypt the block.
     *
     * @returns The padded data, whose length will be a multiple of the
     * plaintext block size of the key.
     */
    public byte[] pad(byte[] plaintext, int off, int len, EncryptionKey key)
        throws PaddingException
    {
        int pbs = key.plainBlockSize();
        if( len>=pbs ) {
            throw new PaddingException( "Trying to pad a partial block of "+len+" bytes with a block size of "+pbs );
        }
        byte[] padded = new byte[pbs];
        System.arraycopy(plaintext, off, padded, 0, len);
        byte padValue = (byte)(pbs-len);
        for( int i=len; i<pbs; i++ ) {
            padded[i] = padValue;
        }
        return padded;
    }


    /**
     * Un-pad the last block of plaintext.
     *
     * @param padded The array holding padded plaintext data.
     * @param off The offset of data within padded array.
     * @param len The length of data within padded array.
     * @param key The key which will be used to decrypt the block.
     *
     * @returns The unpadded data, possibly zero bytes.
     */
    public byte[] unPad(byte[] plaintext, int off, int len, DecryptionKey key)
        throws PaddingException
    {
        int pbs = key.plainBlockSize();
        if( len!=pbs ) {
            throw new PaddingException( "Trying to un-pad a block of "+len+" bytes with a block size of "+pbs );
        }
        byte padByte = plaintext[off+len-1];
        byte[] unpadded = new byte[ len-pbs ];
        System.arraycopy( plaintext,off, unpadded,0, unpadded.length );
        return unpadded;
        /*
        if(bufPos==ibs) {
            byte[] plainblock = new byte[obs];
            key.decrypt(buffer,0, plainblock,0);
            int padValue = plainblock[obs-1]^last[obs-1];
            if( padValue>obs || padValue<1 ) {
                throw new CryptoException( "Invalid amount of padding given in last plaintext block: "+padValue);
            }
            int toReturn = obs-padValue;
            byte[] dest = new byte[toReturn];
            for( int i=0; i<toReturn; i++ ) {
                dest[i] = plainblock[i] ^= last[i];
            }
            return dest;
        }
        throw new CryptoException("Decrypting less than a whole multiple of ciphertext blocks in CBC mode."); */
    }

}
