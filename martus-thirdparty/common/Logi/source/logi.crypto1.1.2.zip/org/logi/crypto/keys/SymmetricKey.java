// Copyright (C) 1998-2001 Logi Ragnarsson

package org.logi.crypto.keys;
import org.logi.crypto.*;
import org.logi.crypto.sign.*;

/**
 * This abstract class implements some (more) of the methods from
 * the Key interface.
 *
 * @see org.logi.crypto.keys.KeyPair
 * @see org.logi.crypto.keys.KeyRing
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
abstract class SymmetricKey
    extends K
{

    // -----------------------------------------------------------
    // INSTANCE METHODS

    /**
     * Calculate the fingerprint for this key using the named hash function.
     * The default behaviour is to return the fingerprint of the CDS for this key. */
    protected Fingerprint calcFingerprint(boolean other, String algorithm) throws InvalidCDSException
    {
        return fingerprint = Fingerprint.create(toString(), algorithm);
    }


    /**
     * Returns true if this and key are the same symmetric key.
     * <p>
     * Symmetric keys simply call <code>equals(key)</code>. */
    public boolean matches(Key key)
    {
        return equals(key);
    }

}
