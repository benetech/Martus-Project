// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.keys;
import org.logi.crypto.*;

/**
 * This is the class for triple-DES keys used in an EDE3 configuration. This
 * is a variant of the standard DES cipher which increases the size of the
 * key-space to make exhaustive key-search infeasible.
 * <p>
 * The CDS for a triple-DES key is <code>TriDESKey(key)</code> with
 * <code>key</code> a string of 48 hexadecimal digits to create a specific
 * key or <code>TriDESKey(?)</code> for a random TriDESKey object.
 *
 * @see org.logi.crypto.keys.DESKey
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class TriDESKey extends SymmetricKey implements CipherKey
{

    private DESKey k1;
    private DESKey k2;
    private DESKey k3;

    /** Create a new random triple-DES key. */
    public TriDESKey()
    {
        k1 = new DESKey();
        k2 = new DESKey();
        k3 = new DESKey();
    }

    /** Create a new triple-DES key with the key bits from <code>key[0..23]</code>. */
    public TriDESKey(byte[] key)
    {
        if(key.length==0)
            throw new ArrayIndexOutOfBoundsException("Creating a zero-length triple-DES key");
        if(key.length<24) {
            byte[] k = new byte[24];
            for(int i=0; i<24; i+=key.length)
                System.arraycopy(key,0, k,i, Math.min(key.length,24-i));
            key=k;
        }
        k1=new DESKey(makeLong(key, 0,8));
        k2=new DESKey(makeLong(key, 8,8));
        k3=new DESKey(makeLong(key,16,8));
    }

    /**
     * Used by Crypto.fromString when parsing a CDS.<p>

     * A valid CDS can be created by calling the toString() method.

     * @exception InvalidCDSException if the CDS is malformed.
     * @see org.logi.crypto.Crypto#fromString(String)
     */
    public static TriDESKey parseCDS(String[] param) throws InvalidCDSException
    {
        if(param.length!=1)
            throw new InvalidCDSException("invalid number of parameters in the CDS TriDESKey(key)");
        if(param[0].equals("?"))
            return new TriDESKey();
        byte[] k = fromHexString(param[0]);
        return new TriDESKey(k);
    }

    /** The block-size for the triple-DES cipher is 8 bytes. */
    public int plainBlockSize()
    {
        return 8;
    }

    /** The block-size for the triple-DES cipher is 8 bytes. */
    public int cipherBlockSize()
    {
        return 8;
    }

    /** The key-size for the triple-DES cipher is 168 bits. */
    public int getSize()
    {
        return 168;
    }

    /** The name of the algorithm is "TriDES". */
    public String getAlgorithm()
    {
        return "TriDES";
    }

    /** Return true iff the two keys are equivalent. */
    public boolean equals(Object o)
    {
        if (o==null)
            return false;
        if (o.getClass() != this.getClass())
            return false;
        TriDESKey k=(TriDESKey)o;
        return k1.equals(k.k1) && k2.equals(k.k2) && k3.equals(k.k3);
    }

    /** Return the key-bits for this key as an array of 24 bytes. */
    public byte[] getKey()
    {
        byte[] k=new byte[24];
        System.arraycopy(k1.getKey(),0, k, 0, 8);
        System.arraycopy(k2.getKey(),0, k, 8, 8);
        System.arraycopy(k3.getKey(),0, k,16, 8);
        return k;
    }

    /**
     * Return a CDS for this key.
     *
     * @see org.logi.crypto.Crypto#fromString
     */
    public String toString()
    {
        StringBuffer sb=new StringBuffer(56);
        sb.append("TriDESKey(");
        sb.append(hexString(k1.getKey()));
        sb.append(hexString(k2.getKey()));
        sb.append(hexString(k3.getKey()));
        sb.append(")");
        return sb.toString();
    }

    /**
     * Encrypt one block of data. The plain data is taken from
     * <code>source[i..i+23]</code> and ciphertext is written to
     * <code>dest[j..j+23]</code>.
     */
    public void encrypt(byte[] source, int i, byte[] dest, int j)
    {
        long block = makeLong(source,i,8);
        block = pickBits(block,DESKey.IP);
        block = k1.subCrypt(block);
        block = k2.subDecrypt(block);
        block = k3.subCrypt(block);
        block = pickBits(block,DESKey.FP);
        writeBytes(block,dest,j,8);
    }

    /**
     * Decrypt one block of data. The encrypted data is taken from
     * <code>dest[i..i+23]</code> and plaintext is written to
     * <code>source[j..j+23]</code>.
     */
    public void decrypt(byte[] source, int i, byte[] dest, int j)
    {
        long block = makeLong(source,i,8);
        block = pickBits(block,DESKey.IP);
        block = k3.subDecrypt(block);
        block = k2.subCrypt(block);
        block = k1.subDecrypt(block);
        block = pickBits(block,DESKey.FP);
        writeBytes(block, dest, j, 8);
    }

}
