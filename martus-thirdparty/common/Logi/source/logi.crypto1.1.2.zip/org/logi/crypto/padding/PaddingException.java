// Copyright (C) 1998-2001 Logi Ragnarsson

package org.logi.crypto.padding;

import org.logi.crypto.*;

/**
 * This exception is thrown whenever a malformed CDS is encountered.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a> (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class PaddingException
            extends CryptoException
{

    /** Create a new PaddingException with no message. */
    public PaddingException()
    {}

    /** Create a new InvalidCDSException with the message msg. */
    public PaddingException(String msg)
    {
        super(msg);
    }

}
