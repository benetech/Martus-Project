// Copyright (C) 1998-2001 Logi Ragnarsson

package org.logi.crypto.protocols;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.modes.*;
import org.logi.crypto.sign.*;
import org.logi.crypto.sign.*;

/**
 * Receive an encrypted key from the correstponding EncryptedKeyExClient
 * and optionally check a signature. <p>

 * This is a non-interactive protocol and the client sends one message to
 * the server containing E(K) and optionally S(H(E(K)))). E is encryption
 * with a CipherKey, S is signing with a Signature key, both set when the
 * object is created. H is the default hash-function, which will be SHA1
 * unless changed.<p>

 * If the key-exchange is performed with a public-key cryptosystem you will
 * almost certainly want to authenticate the client in some way, such as by
 * having him sign the session key.<p>

 * In the case where a symmetric cipher is used for key-exchange and no
 * signatures are used, attacks on the system, such as modified or dropped
 * packages, etc., will be difficult to distinguish from transmission
 * errors.

 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class EncryptedKeyExServer
            extends Crypto
            implements NoninterKeyExServer
{

    private boolean keyDecided=false;

    private DecryptionKey decryptKey;   // key used to decrypt session-key
    private VerificationKey verifyKey;  // key used to verify session-key
    private Key sessionKey;             // the session key


    /**
     * Creates a new EncryptedKeyExchangeServer object. It uses
     * <code>key</code> to decrypt the session key sent to it by the
     * client.
     * <p>
     * If <code>verifyKey</code> is not <code>null</code>, a signature
     * is expected to accompany the session key. If none is found, it
     * will be treated as if a signature was not verified.
     */
    public EncryptedKeyExServer(DecryptionKey key, VerificationKey verifyKey)
    {
        this.decryptKey = decryptKey;
        this.verifyKey = verifyKey;
    }


    /**
     * Returns the key if it has been decided upon,
     * or <code>null</code> otherwise.
     */
    public Key sessionKey()
    {
        return keyDecided ? sessionKey : null;
    }


    /** Returns true iff this end of the protocol i completed. */
    public boolean completed()
    {
        return keyDecided;
    }


    /**
     * Returns the maximum expected size of a message for this protocol. */
    public int maxMessageSize()
    {
        return 65536;
    }


    /**
     * Creates a new EncryptedKeyExchangeServer object. It uses
     * <code>key</code> to decrypt the session key sent to it by the
     * client.  */
    public EncryptedKeyExServer(DecryptionKey decryptKey)
    {
        this.decryptKey=decryptKey;
    }


    /**
     * Get the next message in the protocol.
     * <p>
     * process one message from the client. Since this protocol only
     * requires a single message to be sent from the client to the
     * server with no answer, the message method returns null and
     * can be called independently, any number of times.
     *
     * @exception CryptoProtocolException if a problem arises with the protocol.  */
    public byte[] message(byte[] received) throws CryptoProtocolException
    {
        // message = [ sign-idx | plain key-size | encrypted key | signature ]
        //             ^          ^                ^               ^
        //             0          4                8               signIdx
        //
        // The signature may be an empty string, meaning no signature.

        if(received==null) {
            throw new CryptoProtocolException("null message received");
        }

        try {

            int signIdx = (int)makeLong(received,0,4);

            DecryptSession dm=new DecryptECB(decryptKey);
            int pl=(int)makeLong(received,4,4);
            byte[] p1=dm.decrypt(received,8, signIdx-8);
            byte[] plain;
            if(pl==p1.length) {
                plain=p1;
            } else {
                plain=new byte[pl];
                System.arraycopy(p1,0, plain,0, pl);
            }

            if(verifyKey!=null) {
                if(signIdx==received.length) {
                    throw new CryptoProtocolException("No signature included with key.");
                }

                byte[] s = new byte[received.length-signIdx];
                System.arraycopy(received,signIdx, s,0, s.length);
                Signature signature = new Signature(null, s);
                try {
                    if (!verifyKey.verify(signature, Fingerprint.create(plain,"SHA1")))
                        throw new CryptoProtocolException("Key signature invalid.");
                } catch (InvalidCDSException f) {
                    throw new CryptoCorruptError(f.getMessage());
                }
                catch (CryptoException e) {
                    throw new CryptoProtocolException(e.getMessage());
                }
            }

            try {
                sessionKey = (Key)fromString(new String(plain));
                keyDecided=true;
            } catch (Exception e) {
                e.printStackTrace();
                throw new CryptoProtocolException("Did not receive a valid CDS for a CipherKey object.");
            }

            return null;
        } catch (ArrayIndexOutOfBoundsException e) {
            throw new CryptoProtocolException("Malformed message.");
        }
    }

}
