// Copyright (C) 1998-2001 Logi Ragnarsson

package org.logi.crypto.modes;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;

/**
 * Uninteresting implementation details.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 *         (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
abstract class DecryptMode
            extends Crypto
            implements DecryptSession
{

    /**
     * Decrypt the last part of ciphertext and return plaintext. This will flush any
     * buffers internal to the DecryptSession object.
     */
    public byte[] flush(byte[] source, int i, int length)
    throws CryptoException
    {
        byte[] p1 = decrypt(source, i, length);
        byte[] p2 = flush();
        if( p1.length==0 ) {
            return p2;
        }
        if( p2.length==0 ) {
            return p1;
        }
        byte[] p = new byte[ p1.length + p2.length ];
        System.arraycopy(p1, 0, p, 0, p1.length);
        System.arraycopy(p2, 0, p, p1.length, p2.length);
        return p;
    }

}
