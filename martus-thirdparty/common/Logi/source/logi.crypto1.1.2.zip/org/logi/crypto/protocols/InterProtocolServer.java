// Copyright (C) 1998,2000 Logi Ragnarsson

package org.logi.crypto.protocols;

/**
 * This interface is implemented by classes for the server portion of an
 * interactive protocol.
 *
 * @see org.logi.crypto.protocols.InterProtocolClient
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public interface InterProtocolServer
{

    /** Returns true iff this end of the protocol is completed. */
    public boolean completed();

    /**
     * Get the next message in the protocol.
     * <p>
     * <code>received</code> is the last message received form the client
     * and has not yet been sent to the client.
     * <p>
     * The returned value is the next message to send to the client or null
     * if no more messages need to be sent and the protocol is terminated.
     *
     * @exception CryptoProtocolException if a problem arises with the protocol.
     */
    public byte[] message(byte[] received) throws CryptoProtocolException;

    /**
     * Returns the maximum expected size of a message for this protocol. */
    public int maxMessageSize();

}
