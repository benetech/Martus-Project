// Copyright (C) 1998-2001 Logi Ragnarsson

package org.logi.crypto.modes;

import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.padding.*;

/**
 * Descendants of EncryptSession encrypt arbtrarily large arrays of
 * plaintext.  A corresponding DecryptSession should be used for
 * decryption.
 * <p>
 * Most EncryptSessions use a CipherKey object to do actual
 * encryption and do additional computations to mask repetitions in
 * the plaintext.
 *
 * @see org.logi.crypto.modes.DecryptSession
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 *         (<a href="mailto:logir@logi.org">logir@logi.org</a>) */
public interface EncryptSession
{

    /** Return the key used for encryption. */
    public EncryptionKey getKey();

    /**
     * Set the key to use for encryption. Do not call this method when
     * there may be data in the internal buffer.
     *
     * @exception CryptoException if there is data in the internal buffer
     * which should be encrypted with the old key. */
    public void setKey(EncryptionKey key)
        throws CryptoException;

    /**
     * Return the size of the blocks of plaintext encrypted by this object.
     */
    public int plainBlockSize();

    /**
     * Pads the internal buffer, encrypts it and returns the
     * ciphertext. Also releases any and all resources.
     */
    public byte[] flush()
        throws PaddingException;

    /**
     * Equivalent to calling <code>encrypt(source,i,length)</code>
     * followed by <code>flush()</code>. Also releases any and all
     * resources.
     */
    public byte[] flush(byte[] source, int i, int length)
        throws PaddingException;

    /**
     * Send bytes to the EncryptMode for encryption.
     * <p>
     * Encrypt <code>length</code> bytes from <code>source</code>,
     * starting at <code>i</code> and return the ciphertext. Data may be
     * encrypted in blocks in which case only whole blocks of ciphertext
     * are written to <code>dest</code>. Any remaining plaintext will be
     * stored and prepended to <code>source</code> in the next call to
     * <code>encrypt</code>.
     */
    public byte[] encrypt(byte[] source, int i, int length);

}
