// Copyright (C) 1998-2001 Logi Ragnarsson

package org.logi.crypto.io;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.modes.*;
import org.logi.crypto.protocols.*;

import java.io.*;

/**
 * Decrypt a stream of data encrypted with a corresponding EncryptStream
 * ojbect.
 *
 * @see org.logi.crypto.io.EncryptStream
 * @see org.logi.crypto.modes.DecryptSession
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>) */
public class DecryptStream extends FilterInputStream
{


    /** The decrypt session this stream encapsulates or null if it has already been flushed. */
    private DecryptSession dmode;


    /**
     * <code>buffer[bufPos..buffer.length-1]</code> is the data which
     * has been decrypted but not read from the stream.  It is always
     * a whole multiple of plaitext blocks. */
    private byte[] buffer;
    private int bufPos;


    /** The size of the buffer of ciphertext to read at once. */
    private int cipherBufferSize;


    /**
     * Create a new DecryptStream. Plaintext is written to <code>out</code>,
     * <code>dmode</code> is used for decryption and if <code>kex</code>
     * is not null it will be used to generate the session key or receive i
     * from the client. See the various key-exchange server classes for
     * details.
     * <p>
     * Note that if <code>kex</code> is not null, it controls which
     * session key is used and <code>dmode</code> receives the session key
     * when it has been decided. If <code>kex</code> is null, then
     * <code>dmode</code> must be initialized with a key, and the same symmetric
     * key or matching asymmetric key must be used on the client.
     *
     * @exception CryptoProtocolException if a problem arises with the key-exchange protocol.
     * @exception IOException if problems arise with the underlying OutputStream.  */
    public DecryptStream(InputStream in, NoninterKeyExServer kex, DecryptSession dmode) throws CryptoProtocolException, IOException
    {
        super(in);
        this.dmode=dmode;

        if(kex!=null) {
            reKey(kex, false);
        }
        if(dmode.getKey()==null) {
            throw new CryptoProtocolException("No key specified or exchanged");
        }
        int blockSize=dmode.getKey().cipherBlockSize();
        cipherBufferSize=(1024/blockSize+1)*blockSize;
        buffer=new byte[0];
    }


    /**
     * Return the key used for decrypting this stream, or null if one has
     * not been specified. */
    public DecryptionKey getKey()
    {
        if(dmode==null) {
            return null;
        }
        return dmode.getKey();
    }


    /**
     * Re-key the DecryptSession used by this DecryptStream. This causes the
     * stream to be drained.
     *
     * @exception CryptoException if the internal buffer in the DecryptSession
     * is not empty. */
    public void setKey(CipherKey key)
        throws CryptoException
    {
        drain();
        dmode.setKey(key);
    }


    /**
     * Executes a non-interactive key-exchange protocol. If encrypt is true,
     * messages will be sent through the encrypted channel. This causes the
     * stream to be drained.
     * <p>
     * After the protocol has been executed, the exchanged key will be used
     * for decryption.
     *
     * @exception IOException if there is a low-level problem.
     * @exception CryptoProtocolException if the protocol could not execute.
     */
    public void reKey(NoninterKeyExServer kex, boolean encrypt) throws IOException, CryptoProtocolException
    {
        execute(kex, false);
        try {
            CipherKey key=(CipherKey)kex.sessionKey();
            if(key==null) {
                throw new CryptoProtocolException("A non-interactive protocol should only need one message.");
            }
            dmode.setKey(key);
        } catch (ClassCastException e) {
            throw new CryptoProtocolException("The key-exchange protocol proposes to use a non-cipher key for decryption.");
        } catch (CryptoException ke) {
            throw new CryptoProtocolException(ke.getMessage());
        }
    }


    /**
     * Executes a non-interactive protocol. If encrypt is true, messages will be
     * sent through the encrypted channel.
     *
     * @exception CryptoProtocolException if there is a problem with the protocol.
     * @exception IOException if there is a problem with the underlying streams.
     */
    private void execute(NoninterProtocolServer prot, boolean encrypt) throws IOException, CryptoProtocolException
    {
        InputStream i = (encrypt ? this : in);
        int l = Crypto.readInt(i);
        if(l<0 || l>prot.maxMessageSize()) {
            throw new CryptoProtocolException(l+" is not a valid message size for this protocol.");
        }
        if(l>0) {
            byte[] msg=new byte[l];
            int m = Crypto.readBlock(i, msg, 0, l);
            if (m==-1) {
                throw new CryptoProtocolException("EOF while executing protocol");
            }
            prot.message(msg);
        } else {
            prot.message(null);
        }
        if(!prot.completed()) {
            throw new CryptoProtocolException("The protocol was not completed");
        }

        if(encrypt) {
            drain();
        }
    }


    /**
     * Fills the internal buffer if possible.
     * Returns false iff this stream is at EOF.
     */
    private boolean fillBuffer()
        throws IOException
    {
        byte[] cipher=new byte[cipherBufferSize];
        int l = in.read(cipher);
        if(l==-1) {
            // no more plaintext to read.
            if( dmode!=null ) {
                // we haven't flushed the decrypt session yet.
                try {
                    buffer = dmode.flush();
                    bufPos = 0;
                    dmode = null;
                    return true;
                } catch (CryptoException ce) {
                    throw new IOException( "Caught "+ce );
                }
            } else {
                // we have flushed the decrypt sessions, so we can't have any more data.
                buffer=new byte[0];
                bufPos=0;
                return false;
            }
        }
        buffer=dmode.decrypt(cipher,0,l);
        bufPos=0;
        return true;
    }


    /**
     * Reads the next byte of data from this input stream. The value
     * byte is returned as an int in the range 0 to 255. If no byte is
     * available because the end of the stream has been reached, the
     * value -1 is returned. This method blocks until input data is
     * available, the end of the stream is detected, or an exception
     * is thrown.  */
    public synchronized int read()
        throws IOException
    {
        while(bufPos==buffer.length) {
            // We could read ciphertext from in which is not enough to
            // make a full block, so buffer will have length 0. We
            // then want to read more ciphertext, possibly blocking in
            // the process. Thus thw "while" rather than "if".
            if (!fillBuffer()) {
                return -1;
            }
        }
        return (int)buffer[bufPos++] & 0xff;
    }


    /**
     * Reads up to len bytes of data from this input stream into an array of
     * bytes. This method blocks until some input is available.
     */
    public synchronized int read(byte b[], int off, int len)
        throws IOException
    {
        while(bufPos==buffer.length) {
            // We could read ciphertext from in which is not enough to make
            // a full block, so buffer will have length 0. We then want to
            // read more ciphertext, possibly blocking in the process. Thus
            // thw "while" rather than "if".
            if (!fillBuffer()) {
                return -1;
            }
        }
        int l = (len<=buffer.length-bufPos) ? len : buffer.length-bufPos;
        System.arraycopy(buffer,bufPos, b,off, l);
        bufPos+=l;
        return l;
    }


    /**
     * Returns the number of bytes that can be read from this input
     * stream without blocking. */
    public synchronized int available()
        throws IOException
    {
        int r=buffer.length-bufPos;
        if(r>0)
            // We've got some plain bytes to return
            return r;
        int a=in.available();
        if(a==0)           // The underlying stream is blocked
            return 0;
        // There is ciphertext in the underlying stream
        byte[] ciphertext = new byte[a];
        a=in.read(ciphertext,0,a);
        if(a>0) {           // We actually read some data!
            buffer=dmode.decrypt(ciphertext,0,a);
            bufPos=0;
            return buffer.length-bufPos;
        }
        // Nothing read from the underlying stream (possibly EOF)
        return 0;
    }


    /**
     * Does nothing and returns 0.
     */
    public long skip(long n) throws IOException
    {
        return 0;
    }


    /**
     * Drain random bytes inserted to fill a plain-text block. If
     * <code>flush()</code> was called at this point in creating the
     * stream, <code>drain()</code> will remove the random bytes.
     *
     * @see org.logi.crypto.io.EncryptStream#flush
     */
    public int drain()
    {
        int pbs = dmode.plainBlockSize();  // plain-block size
        int used = (bufPos % pbs);         // bytes used in the last block
        if (used==0) {
            return 0;
        }
        int removed = pbs-used;
        bufPos += removed;                 // drop the rest of the block
        return removed;
    }


    /**
     * Closes this input stream and releases any system resources
     * associated with this stream.
     *
     * @exception IOException if an I/O error occurs. */
    public void close()
    throws IOException
    {
        if( dmode!=null ) {
            try {
                dmode.flush();
            } catch (CryptoException ce) {
                throw new IOException( "Caught "+ce );
            }
        }
        in.close();
    }


    /** Returns false. */
    public boolean markSupported()
    {
        return false;
    }

}
