// Copyright (C) 1999-2000 Logi Ragnarsson

package org.logi.crypto.io;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.sign.*;

import java.io.*;

/**
 * This OutputStream signs everything written to it using the
 * specified HashState and SignatureKey. Alternatively it will embed
 * unsigned hashes of the data within the stream. In either case the
 * embedded hashes or signatures should be verified with a
 * VerifyStream object.
 *
 * @see org.logi.crypto.io.VerifyStream
 * @ version 1.0.6
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>) */
public class SignStream
            extends FilterOutputStream
{

    private HashState fs;
    private SigningKey key;

    private byte[] buffer; // unwritten bytes buffer
    private int bufSize;   // number of bytes in the block
    private int bufPos;    // number of bytes written to current block

    /**
     * Creates a new SignStream. It passes
     * everything written to it through <code>fs</code> and after each
     * approximately <code>blockSize</code> bytes it inserts a signature of the
     * fingerprint into the underlying stream. It then writes the data to
     * <code>out</code>.
     * <p>
     * If <code>key</code> is null the fingerprints will be written unsigned
     * to the underlying stream.
     */
    public SignStream(OutputStream out, int blockSize, SigningKey key, HashState fs)
    {
        super(out);
        this.key = key;
        this.bufSize=(blockSize/fs.blockSize())*fs.blockSize();
        if (this.bufSize==0)
            this.bufSize=fs.blockSize();
        buffer = new byte[this.bufSize];
        this.fs = fs;
    }

    /** Writes the specified byte to this output stream. */
    public synchronized void write(int b)
    throws IOException
    {
        buffer[bufPos++] = (byte)b;
        if (bufPos==bufSize) {
            signAndWrite();
        }
    }

    /**
     * Writes <code>len</code> bytes from the specified byte array starting
     * at offset <code>off</code> to this output stream.
     *
     * @exception IOException if there is a problem iwth the underlying stream
     * or the key fails to sign the fingerprint. */
    public synchronized void write(byte[] buf, int off, int len)
    throws IOException
    {
        while(len>0) {
            int n = (len<bufSize-bufPos) ? len : bufSize-bufPos;
            System.arraycopy(buf,off, buffer,bufPos, n);
            bufPos += n;
            len    -= n;
            off    += n;
            if(bufPos==bufSize) {
                signAndWrite();
            }
        }
    }

    private void signAndWrite()
    throws IOException
    {
        if(bufPos>0) {
            Crypto.writeInt(out,bufPos);
            fs.update(buffer,0,bufPos);
            out.write(buffer,0,bufPos);
            Fingerprint fp=fs.calculate();
            if(key==null) {
                out.write(fp.getBytes());
            } else {
                try {
                    Signature sig=key.sign(fp);
                    out.write(sig.getBytes());
                } catch (CryptoException e) {
                    throw new IOException("Caught exception: "+e);
                }
            }
            bufPos=0;
        }
    }

    /**
     * Flushes this output stream and forces any buffered output bytes to
     * be written out to the stream.
     */
    public synchronized void flush()
    throws IOException
    {
        signAndWrite();
        out.flush();
    }

    /**
     * Closes this output stream and releases any system resources associated
     * with this stream.
     *
     * @exception IOException if there is a problem with the underlying stream
     * or the key fails to sign the fingerprint.
     */
    public synchronized void close()
    throws IOException
    {
        flush();
        out.close();
    }

}
