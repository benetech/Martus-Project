// Copyright (C) 1998-2001 Logi Ragnarsson

package org.logi.crypto.sign;

import org.logi.crypto.*;

/**
 * Information used for blinding a fingerprint and unblinding a signature
 * for a particular keypair. Only use a blinding factor once!

 * @author <a href="http://www.logi.org/">Logi Ragnarsson</a> (<a href="mailto:logi@logi.org">logi@logi.org</a>)
 */
public abstract class BlindingFactor
    extends Crypto
{
}
