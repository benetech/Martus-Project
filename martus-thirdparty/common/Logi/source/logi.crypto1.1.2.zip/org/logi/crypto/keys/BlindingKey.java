// Copyright (C) 1998-1999 Logi Ragnarsson

package org.logi.crypto.keys;
import org.logi.crypto.*;
import org.logi.crypto.sign.*;

/**
 * This interface is implemented by keys that can be used to
 * create and validate blind signatures on fingerprints of data.<p>
 
 * Obviously blind signatures should be used with care since you do not
 * know what is being signed. The key used for blind signatures should be
 * created specifically for one purpose and never be used for anything
 * else.
 
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>) */
public interface BlindingKey
            extends VerificationKey
{


    /**
     * Create a new blinding factor suitable for blinding a fingerprint
     * before being signed with the private key in the pais.
     */
    public BlindingFactor createBlindingFactor();


    /**
     * Blind a fingerprint with a public key and the given blinding factor
     * in preparation for blindly signing the fingerprint with the private
     * key.

     * @exception KeyException if there are problems, depending on the implementing class.
     */
    public BlindFingerprint blind(Fingerprint fp, BlindingFactor bf)
    throws CryptoException;


    /**
     * Unblind a blind signature using the same blinding factor that was
     * used to blind the original fingerprint.

     * @exception KeyException if there are problems, depending on the implementing class.
     */
    public Signature unBlind(BlindSignature bs, BlindingFactor bf)
    throws CryptoException;

}
