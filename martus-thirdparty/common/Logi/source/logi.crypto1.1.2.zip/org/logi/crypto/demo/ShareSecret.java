// Copyright (C) 2000-2001 Logi Ragnarsson

package org.logi.crypto.demo;
import org.logi.crypto.*;
import org.logi.crypto.secretshare.*;

/**
 * This program shares the secret on standard input. Run without parameters
 * for details.

 * @see org.logi.crypto.demo.RetrieveSecret
 */
public class ShareSecret
    extends Crypto
{

    private static void error(Object msg)
    {
        if(msg!=null) {
            System.err.println(msg);
            System.err.println();
        }
        System.err.println("Use: java org.logi.crypto.demo.SecretShare m [n]");
        System.err.println();
        System.err.println("This will read a secret from standard input and split it");
        System.err.println("into n different shares. Of these, m are required to retrieve");
        System.err.println("it and m defaults to the same value as n.");
        System.err.println();
        System.err.println("If n==m the xor secret sharing method is used, but if they");
        System.err.println("different, modular polynomials will be used. The poly method");
        System.err.println("is very slow for large secrets, so it may be a better idea to");
        System.err.println("encrypt the secret and to share the key with this program.");
        System.err.println();
        System.err.println("This program can be combined with the RetreiveSecret program with:");
        System.err.println("   java org.logi.crypto.demo.ShareSecret m [n] |");
        System.err.println("   java org.logi.crypto.demo.RetrieveSecret");
        System.err.println("on one line at a unix-like command line.");
        System.exit(1);
    }

    public static void main(String[] arg) throws Exception
    {
        Crypto.initRandom();

        if(arg.length<1 || arg.length>2) {
            error("Invalid number of parameters");
        }

        try {

            // Get the numbers n and m that describe how many shares are
            // needed to retrieve the secret and how many shares are created
            int m=Integer.parseInt(arg[0]);
            int n=m;
            if(arg.length==2) {
                n=Integer.parseInt(arg[1]);
            }

            byte[] secret;
            {  // Read standard input into secret
                secret = new byte[16];
                int secretSize = 0;
                byte[] block=new byte[1024];
                int b = System.in.read(block);
                while(b>0) {
                    secret = ensureArrayLength(secret, secretSize, secretSize+b);
                    System.arraycopy(block,0, secret,secretSize, b);
                    secretSize += b;
                    b = System.in.read(block);
                }
                secret = trimArrayLength(secret, secretSize);
            }

            SecretShare[] shares;
            if(n==m) {
                // Share secret using the xor method
                shares = XorSecretShare.share(m,secret);
            } else {
                // Share secret using a polynomial
                shares = PolySecretShare.share(m,n,secret,512);
            }

            // Write shares
            for(int i=0; i<shares.length; i++) {
                System.out.println(shares[i]);
            }

        } catch (Exception e) {
            error(e);
        }
    }

}
