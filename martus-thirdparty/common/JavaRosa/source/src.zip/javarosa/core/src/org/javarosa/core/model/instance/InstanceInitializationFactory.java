/**
 *
 */
package org.javarosa.core.model.instance;

/**
 * @author ctsims
 *
 */
public class InstanceInitializationFactory {
	public AbstractTreeElement generateRoot(DataInstance instance) {
		return null;
	}
}
