/**
 * 
 */
package org.javarosa.core.model;

import org.javarosa.core.util.externalizable.Externalizable;

/**
 * @author ctsims
 *
 */
public interface XFormExtension extends Externalizable {

}
