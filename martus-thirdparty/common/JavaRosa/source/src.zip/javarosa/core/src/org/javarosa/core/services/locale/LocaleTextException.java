/**
 * 
 */
package org.javarosa.core.services.locale;

/**
 * @author ctsims
 *
 */
public class LocaleTextException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2852964609244258589L;

	public LocaleTextException(String message) {
		super(message);
	}
}
