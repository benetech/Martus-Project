/**
 * 
 */
package org.javarosa.core.services.storage;

/**
 * 
 * Tag interface for defining that models used in storage should be stored
 * in the most secure way possible.
 * 
 * @author ctsims
 *
 */
public interface Secure {

}
