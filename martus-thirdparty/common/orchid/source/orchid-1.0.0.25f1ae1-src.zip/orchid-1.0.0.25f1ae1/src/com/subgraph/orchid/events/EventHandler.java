package com.subgraph.orchid.events;

public interface EventHandler {
	void handleEvent(Event event);
}
