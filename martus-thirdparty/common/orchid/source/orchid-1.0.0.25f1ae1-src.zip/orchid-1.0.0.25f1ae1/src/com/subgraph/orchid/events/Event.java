package com.subgraph.orchid.events;

public interface Event {}
