package com.subgraph.orchid.sockets.sslengine;

public interface HandshakeCallbackHandler {
	void handshakeCompleted();
}
