package javax.crypto;

/**
 * this is a place holder class, no exemption mechanism facility is
 * required in this modified version of the JCE
 */
public class ExemptionMechanism
{
}
